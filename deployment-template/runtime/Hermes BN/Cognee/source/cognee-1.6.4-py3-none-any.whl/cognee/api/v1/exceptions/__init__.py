"""
Custom exceptions for the Cognee API.

This module defines a set of exceptions for handling various data errors
"""

from .exceptions import (
    InvalidConfigAttributeError,
    DocumentNotFoundError,
    DatasetNotFoundError,
    DataNotFoundError,
    DocumentSubgraphNotFoundError,
    DocumentUpdateRequiredError,
    UpdateTargetNotFoundError,
)

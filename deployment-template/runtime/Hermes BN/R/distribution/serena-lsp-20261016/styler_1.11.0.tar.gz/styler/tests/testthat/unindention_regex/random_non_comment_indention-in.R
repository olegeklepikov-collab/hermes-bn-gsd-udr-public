a <- function() {
 bbx
  x
  }

#' Lintr
#'
#' Checks adherence to a given style, syntax errors, and possible semantic
#'   issues.
#' Supports on the fly checking of R code edited with Emacs, Vim, and
#'   Sublime Text.
#'
#' @seealso [lint()], [lint_package()], [lint_dir()], [linters]
#' @keywords internal
"_PACKAGE"

## lintr namespace: start
#' @importFrom cli cli_inform cli_abort cli_warn qty
#' @importFrom glue glue glue_collapse
#' @importFrom rex rex regex re_matches re_substitutes character_class
#' @importFrom stats complete.cases na.omit
#' @importFrom tools R_user_dir
#' @importFrom utils capture.output getParseData  globalVariables head
#' @importFrom utils relist tail
#' @importFrom xml2 xml_attr xml_attrs xml_child xml_children xml_find_all
#' @importFrom xml2 xml_find_chr xml_find_first xml_find_lgl xml_find_num
#' @importFrom xml2 xml_missing xml_name xml_parent xml_text
## lintr namespace: end
NULL

# make binding available for mock testing
# ref: https://testthat.r-lib.org/dev/reference/local_mocked_bindings.html#base-functions
# nolint start: object_name_linter. These will be copied from base style.
requireNamespace <- NULL
system.file <- NULL
unlink <- NULL
quit <- NULL
# nolint end: object_name_linter.

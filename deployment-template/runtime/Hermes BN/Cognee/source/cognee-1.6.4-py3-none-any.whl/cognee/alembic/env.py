import asyncio
import logging
from logging.config import fileConfig

from alembic import context
from sqlalchemy import pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

import cognee.modules.migrations.models
import cognee.modules.provenance.edge_evidence.models
import cognee.modules.provenance.models
import cognee.modules.session_lifecycle.models
from cognee.infrastructure.databases.relational import Base, get_relational_engine

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically. Programmatic invocations (cognee's
# startup migrations run alembic in-process) set configure_logger=False so
# this does not clobber the host process's logging configuration.
if config.config_file_name is not None and config.attributes.get("configure_logger", True):
    fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support
# from myapp import mymodel
# target_metadata = mymodel.Base.metadata

target_metadata = Base.metadata

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    context.configure(connection=connection, target_metadata=target_metadata)

    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    """In this scenario we need to create an Engine
    and associate a connection with the context.
    """

    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)

    await connectable.dispose()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode."""

    asyncio.run(run_async_migrations())


# The engine to migrate: an adapter handed in through config.attributes (an
# adapter's create_database() builds ITS OWN database, not the global one),
# else the globally configured engine.
db_engine = config.attributes.get("relational_engine") or get_relational_engine()

# Use the LIVE engine's URL, not db_uri: for S3-backed SQLite the adapter
# pulls the database to a local temp file and connects to THAT (db_uri still
# names the s3:// path, which aiosqlite cannot open). The live engine's URL
# always points at the real connection target on every backend.
db_uri = db_engine.engine.url.render_as_string(hide_password=False)

logging.getLogger("alembic.env").info(
    "Using database: %s", db_engine.engine.url.render_as_string(hide_password=True)
)

config.set_section_option(
    config.config_ini_section,
    "SQLALCHEMY_DATABASE_URI",
    db_uri,
)


if context.is_offline_mode():
    print("OFFLINE MODE")
    run_migrations_offline()
else:
    run_migrations_online()

"""Postgres graph adapter using two tables (graph_node, graph_edge) over SQLAlchemy + asyncpg.

DEMO: Using Postgres as a graph store is currently a demo feature and is not
production-ready. Use it to demo keeping relational metadata, PGVector, and graph
state in a single Postgres service, but rely on a graph-native backend such as Kuzu or Neo4j
for production workloads.

Interested in further development or production use of Postgres as a graph database? Write to
us at social@cognee.ai to explore the options.
"""

import asyncio
import json
from collections.abc import AsyncIterator, Callable
from contextlib import asynccontextmanager
from typing import Any
from uuid import UUID

from sqlalchemy import NullPool, text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from cognee.infrastructure.databases.graph.bounded_neighborhood import (
    DEFAULT_NEIGHBORHOOD_CHUNK_SIZE,
    unique_node_ids,
    validate_bounded_neighborhood_args,
)
from cognee.infrastructure.databases.graph.graph_db_interface import (
    GraphDBInterface,
    temporal_anchors_from_rows,
)
from cognee.infrastructure.databases.provenance import (
    EdgeDeleteData,
    EdgeIdentity,
    NodeDeleteData,
)
from cognee.infrastructure.databases.provenance.source_ref_state import (
    ProvenanceColumns,
    provenance_after_attach,
    provenance_after_remove,
)
from cognee.infrastructure.databases.provenance.source_refs import (
    get_dataset_id_from_source_ref_key,
    get_pipeline_run_id_from_source_run_ref,
    get_source_ref_key_from_source_run_ref,
)
from cognee.infrastructure.databases.relational import get_relational_config
from cognee.infrastructure.engine import DataPoint
from cognee.modules.graph.methods.sanitize_relational_payload import sanitize_relational_payload
from cognee.modules.storage.utils import JSONEncoder

from .tables import _meta


def _prepare_node_rows(
    nodes: list[tuple[str, dict]] | list[DataPoint],
) -> list[dict[str, Any]]:
    """Copy, sanitize, deduplicate, and sort nodes for one database write."""
    rows_by_id: dict[str, dict[str, Any]] = {}
    for node in nodes:
        if isinstance(node, tuple):
            properties = {**(node[1] or {}), "id": node[0]}
        elif hasattr(node, "model_dump"):
            properties = dict(node.model_dump())
        else:
            properties = dict(vars(node))

        node_id = sanitize_relational_payload(str(properties.get("id", "")))
        extra = {
            key: value for key, value in properties.items() if key not in {"id", "name", "type"}
        }
        rows_by_id[node_id] = {
            "id": node_id,
            "name": sanitize_relational_payload(str(properties.get("name", ""))),
            "type": sanitize_relational_payload(str(properties.get("type", ""))),
            "properties": json.dumps(sanitize_relational_payload(extra), cls=JSONEncoder),
        }

    return [rows_by_id[node_id] for node_id in sorted(rows_by_id)]


def _prepare_edge_rows(
    edges: list[tuple[str, str, str, dict[str, Any] | None]],
) -> list[dict[str, Any]]:
    """Copy, sanitize, deduplicate, and sort edges for one database write."""
    rows_by_identity: dict[tuple[str, str, str], dict[str, Any]] = {}
    for source_id, target_id, relationship_name, *property_values in edges:
        identity = (
            sanitize_relational_payload(str(source_id)),
            sanitize_relational_payload(str(target_id)),
            sanitize_relational_payload(str(relationship_name)),
        )
        properties = property_values[0] if property_values and property_values[0] else {}
        rows_by_identity[identity] = {
            "source_id": identity[0],
            "target_id": identity[1],
            "relationship_name": identity[2],
            "properties": json.dumps(
                sanitize_relational_payload(dict(properties)), cls=JSONEncoder
            ),
        }

    return [rows_by_identity[identity] for identity in sorted(rows_by_identity)]


def _edge_identities(edges: list[EdgeIdentity]) -> list[tuple[str, str, str]]:
    """Deduplicate edge identities, sorted so concurrent writers lock rows in one order."""
    return sorted(
        {(str(edge.source_id), str(edge.target_id), str(edge.relationship_name)) for edge in edges}
    )


# Every write in this adapter takes this one advisory lock first, so two write
# transactions never overlap. Row locks alone are not enough: concurrent batches
# inserting the same node wait on each other's unique index entry, and a cascading
# delete waits on rows in a different order, which Postgres reports as a deadlock.
# An xact-level advisory lock is released on commit and on rollback, so there is no
# unlock path to forget. Reads never take it.
_GRAPH_WRITE_LOCK_KEY = 5522063


async def _lock_graph_writes(session: AsyncSession) -> None:
    """Serialize graph writes for the rest of this transaction."""
    await session.execute(
        text("SELECT pg_advisory_xact_lock(:key)"), {"key": _GRAPH_WRITE_LOCK_KEY}
    )


def _decode_properties(value: Any) -> dict[str, Any]:
    """Return a new dictionary for a JSONB value."""
    if not value:
        return {}
    return dict(value) if isinstance(value, dict) else json.loads(value)


def _component_sizes(node_ids: list[str], edge_pairs: list[tuple[str, str]]) -> list[int]:
    """Return the sizes of undirected connected components, largest first."""
    neighbors: dict[str, set[str]] = {node_id: set() for node_id in node_ids}
    for source_id, target_id in edge_pairs:
        neighbors.setdefault(source_id, set()).add(target_id)
        neighbors.setdefault(target_id, set()).add(source_id)

    unseen = set(node_ids)
    sizes = []
    while unseen:
        pending = [unseen.pop()]
        size = 0
        while pending:
            node_id = pending.pop()
            size += 1
            new_neighbors = neighbors.get(node_id, set()) & unseen
            unseen.difference_update(new_neighbors)
            pending.extend(new_neighbors)
        sizes.append(size)

    return sorted(sizes, reverse=True)


def _select_nodeset_neighbor_ids(
    primary_ids: set[str], edge_pairs: list[tuple[str, str]], operator: str
) -> set[str]:
    """Select neighbors connected to any or every primary node."""
    if operator not in {"OR", "AND"}:
        raise ValueError("node_name_filter_operator must be 'OR' or 'AND'")
    if not primary_ids:
        return set()

    connected_primaries: dict[str, set[str]] = {}
    for source_id, target_id in edge_pairs:
        if source_id in primary_ids:
            connected_primaries.setdefault(target_id, set()).add(source_id)
        if target_id in primary_ids:
            connected_primaries.setdefault(source_id, set()).add(target_id)

    if operator == "OR":
        return set(connected_primaries)
    return {
        node_id
        for node_id, connections in connected_primaries.items()
        if connections >= primary_ids
    }


_DEFAULT_POOL_ARGS = {
    "pool_size": 2,
    "max_overflow": 20,  # 22-connection ceiling, PER DATASET
    "pool_pre_ping": True,
    "pool_recycle": 280,
    "pool_timeout": 280,
}


def _resolve_engine_args(configured_pool_args) -> dict:
    """Turn the configured POOL_ARGS into create_async_engine kwargs.

    Defaults mirror PGVectorAdapter._ACCESS_CONTROL_DEFAULT_POOL_ARGS (2/20),
    NOT SqlAlchemyAdapter's 5/35. Like PGVector's, this engine is created per
    dataset — the engine-cache key includes graph_database_schema — so its
    ceiling is multiplied by dataset count, not paid once. dict() handles the
    config's tuple-of-pairs form (relational/config.py stores POOL_ARGS as
    tuple(sorted(parsed.items()))).

    Until now only ``poolclass == "nullpool"`` was honoured and every sizing key
    was dropped, so the adapter always ran SQLAlchemy's stock 5/10/30s pool.
    """
    pool_args = dict(configured_pool_args or {})
    if str(pool_args.get("poolclass", "")).lower() == "nullpool":
        return {"poolclass": NullPool}
    pool_args.pop("poolclass", None)
    for key, value in _DEFAULT_POOL_ARGS.items():
        pool_args.setdefault(key, value)
    return pool_args


class PostgresDemoAdapter(GraphDBInterface):
    """Reference graph adapter using one node table and one directed-edge table."""

    supports_cypher_queries = False

    # Chunk-level incremental updates: get_connections yields the true edge
    # endpoints, provenance lives in-graph, and update_chunk_index below is the
    # narrow single-property move the incremental path requires.
    supports_incremental_chunk_updates = True

    _ALLOWED_FILTER_ATTRS = {"id", "name", "type"}

    def __init__(self, connection_string: str, schema: str = "") -> None:
        """Create engine and sessionmaker from a Postgres connection string.

        When ``schema`` is set (shared-database isolation mode) the connection's
        ``search_path`` is pinned to that schema so the two fixed tables
        (``graph_node``/``graph_edge``) and every unqualified query resolve
        inside the dataset's own schema. This lets many datasets share one
        database — no per-dataset database and no rewriting of the adapter's
        SQL. The path is the dataset schema only (``pg_catalog`` is always
        searched implicitly for built-ins), so neither reads nor
        ``create_all(checkfirst=True)`` can ever fall through to ``public``.
        """
        self.db_uri = connection_string
        self.schema = schema or ""

        relational_config = get_relational_config()
        engine_args = _resolve_engine_args(relational_config.pool_args)
        connect_args: dict = (
            dict(relational_config.database_connect_args)
            if relational_config.database_connect_args
            else {}
        )

        if self.schema:
            server_settings = dict(connect_args.get("server_settings") or {})
            server_settings["search_path"] = self.schema
            connect_args["server_settings"] = server_settings

        self.engine = create_async_engine(
            self.db_uri,
            json_serializer=lambda obj: json.dumps(obj, cls=JSONEncoder),
            connect_args=connect_args,
            **engine_args,
        )
        self.sessionmaker = async_sessionmaker(bind=self.engine, expire_on_commit=False)
        self._write_gate = None
        self._write_gate_loop = None
        self._initialized = False
        self._init_lock = None
        self._init_lock_loop = None

    def _get_write_gate(self) -> asyncio.Lock:
        """Per-running-loop write gate.

        The adapter is process-cached (closing_lru_cache) and can outlive the
        loop it was built on; an asyncio.Lock binds to the first loop that
        awaits it, so an __init__-time Lock is a latent "bound to a different
        event loop" RuntimeError under repeated asyncio.run (CLI, unit tests).
        Correctness never depends on this lock — pg_advisory_xact_lock does —
        so a fresh gate per loop is safe.
        """
        loop = asyncio.get_running_loop()
        if self._write_gate_loop is not loop:
            self._write_gate = asyncio.Lock()
            self._write_gate_loop = loop
        return self._write_gate

    def _get_init_lock(self) -> asyncio.Lock:
        """Per-running-loop lock for initialize(); same rationale as the write gate."""
        loop = asyncio.get_running_loop()
        if self._init_lock_loop is not loop:
            self._init_lock = asyncio.Lock()
            self._init_lock_loop = loop
        return self._init_lock

    @asynccontextmanager
    async def _write_session(self):
        """One serialized graph-write transaction.

        Writes are already serialized cluster-wide by pg_advisory_xact_lock.
        Without this process-local gate every concurrent writer checks a
        connection out of the pool and *then* blocks on that advisory lock, so
        N in-flight writers pin min(N, pool ceiling) connections while exactly
        one makes progress — starving the adapter's own reads (see
        get_graph_metadata). The gate puts the queue in front of the pool
        instead of behind it. It is an optimization, not the correctness
        mechanism: the advisory lock still orders writes across processes.
        """
        async with self._get_write_gate(), self.sessionmaker() as session:
            await _lock_graph_writes(session)
            yield session

    async def close(self) -> None:
        """Dispose the database engine."""
        await self.engine.dispose(close=True)
        self._initialized = False

    async def initialize(self) -> None:
        """Create the graph schema when absent. Idempotent per adapter.

        Every get_graph_engine() builds a fresh _GraphEngineHandle whose
        _ensure_initialized calls this, and get_graph_metadata()/is_empty()
        call it again — so a 164-item batch ran hundreds of
        create_all(checkfirst=True) reflections, each holding a pooled
        connection for a stack of catalog round-trips. That is what exhausted
        the pool on the read path (job 98411831471).
        """
        if self._initialized:
            return
        async with self._get_init_lock():
            if self._initialized:
                return
            async with self.engine.begin() as conn:
                await conn.run_sync(_meta.create_all, checkfirst=True)
            self._initialized = True

    async def query(self, query_str: str, params: dict | None = None) -> list[Any]:
        """Reject raw Cypher; callers must use the typed graph methods."""
        raise NotImplementedError(
            "The Postgres graph backend does not support raw Cypher queries. "
            "Use a Cypher-capable graph backend (Neo4j, Ladybug) for raw query support, "
            "or use the typed adapter methods (add_nodes, get_neighbors, etc.)."
        )

    async def is_empty(self) -> bool:
        """Return whether the graph contains no nodes."""
        await self.initialize()
        async with self.sessionmaker() as session:
            result = await session.execute(text("SELECT EXISTS(SELECT 1 FROM graph_node LIMIT 1)"))
            return not result.scalar()

    async def add_node(
        self, node: DataPoint | str, properties: dict[str, Any] | None = None
    ) -> None:
        """Add one node, given either a DataPoint or a node id with properties."""
        if isinstance(node, str):
            await self.add_nodes([(node, properties or {})])
        else:
            await self.add_nodes([node])

    async def add_nodes(
        self,
        nodes: list[tuple[str, dict]] | list[DataPoint],
        source_ref_key: str | None = None,
        pipeline_run_id: str | None = None,
    ) -> None:
        """Add or replace nodes, optionally attaching one provenance reference."""
        if not nodes:
            return

        rows = _prepare_node_rows(nodes)
        # Provenance columns are absent here on purpose: a rewrite without a
        # source ref must not erase existing ownership.
        upsert = text("""
            INSERT INTO graph_node (id, name, type, properties, created_at, updated_at)
            VALUES (:id, :name, :type, CAST(:properties AS jsonb), now(), now())
            ON CONFLICT (id) DO UPDATE SET
                name = EXCLUDED.name,
                type = EXCLUDED.type,
                properties = EXCLUDED.properties,
                updated_at = now()
        """)
        async with self._write_session() as session:
            await session.execute(upsert, rows)
            if source_ref_key is not None:
                await self._update_node_provenance(
                    session,
                    [row["id"] for row in rows],
                    lambda keys, run_refs: provenance_after_attach(
                        keys, run_refs, [source_ref_key], pipeline_run_id
                    ),
                )
            await session.commit()

    async def update_chunk_index(self, chunk_indexes: dict) -> None:
        """Set ONLY ``chunk_index`` on the given chunk nodes.

        Node properties live in one JSONB column, so the move is a ``jsonb_set``
        of that single key; name, type, every other property and the provenance
        columns are untouched. Missing ids are skipped, like ``get_nodes``.
        """
        if not chunk_indexes:
            return
        rows = [
            {"id": str(node_id), "chunk_index": int(chunk_index)}
            for node_id, chunk_index in chunk_indexes.items()
        ]
        statement = text("""
            UPDATE graph_node
            SET properties = jsonb_set(
                    COALESCE(properties, '{}'::jsonb),
                    '{chunk_index}',
                    to_jsonb(CAST(:chunk_index AS integer)),
                    true
                ),
                updated_at = now()
            WHERE id = :id
        """)
        async with self.sessionmaker() as session:
            await _lock_graph_writes(session)
            await session.execute(statement, rows)
            await session.commit()

    async def delete_node(self, node_id: str) -> None:
        """Delete one node. Delegates to delete_nodes."""
        await self.delete_nodes([node_id])

    async def delete_nodes(self, node_ids: list[str]) -> None:
        """Delete nodes by id; the schema's foreign keys remove their incident edges."""
        if not node_ids:
            return
        async with self._write_session() as session:
            await session.execute(
                text("DELETE FROM graph_node WHERE id = ANY(:ids)"),
                {"ids": [str(node_id) for node_id in node_ids]},
            )
            await session.commit()

    async def get_node(self, node_id: str) -> dict[str, Any] | None:
        """Return one flat node dictionary, or None when the node does not exist."""
        results = await self.get_nodes([node_id])
        return results[0] if results else None

    async def has_node(self, node_id: str) -> bool:
        """Return True when a node with the given id exists."""
        async with self.sessionmaker() as session:
            result = await session.execute(
                text("SELECT EXISTS(SELECT 1 FROM graph_node WHERE id = :id)"),
                {"id": str(node_id)},
            )
            return bool(result.scalar())

    async def get_nodes(self, node_ids: list[str]) -> list[dict[str, Any]]:
        """Return flat node dictionaries, omitting ids that do not exist."""
        if not node_ids:
            return []
        async with self.sessionmaker() as session:
            result = await session.execute(
                text("SELECT id, name, type, properties FROM graph_node WHERE id = ANY(:ids)"),
                {"ids": [str(node_id) for node_id in node_ids]},
            )
            return [
                {
                    "id": row["id"],
                    "name": row["name"],
                    "type": row["type"],
                    **_decode_properties(row["properties"]),
                }
                for row in result.mappings().all()
            ]

    async def get_timestamps_in_range(
        self, start: int | None, end: int | None
    ) -> list[dict[str, Any]]:
        """Timestamp nodes whose ``[time_at, time_until)`` overlaps ``[start, end)``."""
        conditions = ["type = 'Timestamp'"]
        params: dict[str, Any] = {}
        if end is not None:
            conditions.append("(properties->>'time_at')::bigint < :window_end")
            params["window_end"] = int(end)
        if start is not None:
            conditions.append(
                "COALESCE((properties->>'time_until')::bigint, (properties->>'time_at')::bigint + 1000) > :window_start"
            )
            params["window_start"] = int(start)
        async with self.sessionmaker() as session:
            result = await session.execute(
                text(
                    "SELECT id, properties->>'timestamp_str' AS timestamp_str, "
                    "(properties->>'time_at')::bigint AS time_at, "
                    "COALESCE((properties->>'time_until')::bigint, (properties->>'time_at')::bigint + 1000) AS time_until "
                    f"FROM graph_node WHERE {' AND '.join(conditions)} ORDER BY time_at, id"
                ),
                params,
            )
            return [
                {
                    "id": row["id"],
                    "type": "Timestamp",
                    "timestamp_str": row["timestamp_str"],
                    "time_at": row["time_at"],
                    "time_until": row["time_until"],
                }
                for row in result.mappings().all()
            ]

    async def get_temporal_anchors(
        self,
        chunk_ids,
        entity_ids,
        start: int | None,
        end: int | None,
    ) -> dict[str, set[str]]:
        """Candidates attached to a Timestamp overlapping ``[start, end)``: directly,
        or (for chunks) through an entity they ``contains``. See the interface."""
        chunk_list = sorted({str(node_id) for node_id in chunk_ids})
        entity_list = sorted({str(node_id) for node_id in entity_ids})
        if not chunk_list and not entity_list:
            return temporal_anchors_from_rows([], [], [])
        conditions = ["t.type = 'Timestamp'"]
        params: dict[str, Any] = {}
        if end is not None:
            conditions.append("(t.properties->>'time_at')::bigint < :window_end")
            params["window_end"] = int(end)
        if start is not None:
            conditions.append(
                "COALESCE((t.properties->>'time_until')::bigint, (t.properties->>'time_at')::bigint + 1000) > :window_start"
            )
            params["window_start"] = int(start)
        where = " AND ".join(conditions)
        async with self.sessionmaker() as session:
            direct = await session.execute(
                text(
                    "SELECT DISTINCT e.source_id AS candidate_id, t.id AS timestamp_id "
                    "FROM graph_edge e "
                    "JOIN graph_node t ON t.id = e.target_id "
                    f"WHERE e.source_id = ANY(:candidate_ids) AND {where}"
                ),
                {**params, "candidate_ids": chunk_list + entity_list},
            )
            direct_rows = [
                (row["candidate_id"], row["timestamp_id"]) for row in direct.mappings().all()
            ]
            via_rows = []
            if chunk_list:
                via = await session.execute(
                    text(
                        "SELECT DISTINCT e1.source_id AS chunk_id, e2.source_id AS entity_id, t.id AS timestamp_id "
                        "FROM graph_edge e1 "
                        "JOIN graph_node en ON en.id = e1.target_id "
                        "JOIN graph_edge e2 ON e2.source_id = e1.target_id "
                        "JOIN graph_node t ON t.id = e2.target_id "
                        "WHERE e1.source_id = ANY(:chunk_ids) AND e1.relationship_name = 'contains' "
                        f"AND en.type = 'Entity' AND {where}"
                    ),
                    {**params, "chunk_ids": chunk_list},
                )
                via_rows = [
                    (row["chunk_id"], row["entity_id"], row["timestamp_id"])
                    for row in via.mappings().all()
                ]
        return temporal_anchors_from_rows(direct_rows, via_rows, chunk_list)

    async def add_edge(
        self,
        source_id: str,
        target_id: str,
        relationship_name: str,
        properties: dict[str, Any] | None = None,
    ) -> None:
        """Add one directed edge. Delegates to add_edges."""
        await self.add_edges(
            [(str(source_id), str(target_id), relationship_name, properties or {})]
        )

    async def add_edges(
        self,
        edges: list[tuple[str, str, str, dict[str, Any] | None]] | list,
        source_ref_key: str | None = None,
        pipeline_run_id: str | None = None,
    ) -> None:
        """Add or replace edges, optionally attaching one provenance reference."""
        if not edges:
            return

        rows = _prepare_edge_rows(edges)
        # Provenance columns are absent here on purpose: a rewrite without a
        # source ref must not erase existing ownership.
        upsert = text("""
            INSERT INTO graph_edge (
                source_id, target_id, relationship_name, properties, created_at, updated_at
            )
            VALUES (
                :source_id, :target_id, :relationship_name,
                CAST(:properties AS jsonb), now(), now()
            )
            ON CONFLICT (source_id, target_id, relationship_name) DO UPDATE SET
                properties = EXCLUDED.properties,
                updated_at = now()
        """)
        async with self._write_session() as session:
            await session.execute(upsert, rows)
            if source_ref_key is not None:
                await self._update_edge_provenance(
                    session,
                    [
                        EdgeIdentity(
                            source_id=row["source_id"],
                            target_id=row["target_id"],
                            relationship_name=row["relationship_name"],
                        )
                        for row in rows
                    ],
                    lambda keys, run_refs: provenance_after_attach(
                        keys, run_refs, [source_ref_key], pipeline_run_id
                    ),
                )
            await session.commit()

    async def has_edge(self, source_id: str, target_id: str, relationship_name: str) -> bool:
        """Return whether one directed edge triple exists."""
        result = await self.has_edges([(str(source_id), str(target_id), relationship_name)])
        return len(result) > 0

    async def has_edges(self, edges: list[tuple[str, str, str]]) -> list[tuple[str, str, str]]:
        """Return the subset of the requested directed triples that exist."""
        if not edges:
            return []

        found: list[tuple[str, str, str]] = []
        statement = text("""
            SELECT EXISTS(
                SELECT 1 FROM graph_edge
                WHERE source_id = :source_id
                  AND target_id = :target_id
                  AND relationship_name = :relationship_name
            )
        """)
        async with self.sessionmaker() as session:
            for source_id, target_id, relationship_name in edges:
                identity = (str(source_id), str(target_id), str(relationship_name))
                result = await session.execute(
                    statement,
                    {
                        "source_id": identity[0],
                        "target_id": identity[1],
                        "relationship_name": identity[2],
                    },
                )
                if result.scalar():
                    found.append(identity)

        return found

    async def get_edges(self, node_id: str) -> list[tuple[dict[str, Any], str, dict[str, Any]]]:
        """Return every incident edge with its directed source and target nodes."""
        rows = await self._fetch_incident_edge_rows(str(node_id))
        edges = []
        for row in rows:
            source = {
                "id": row["source_id"],
                "name": row["source_name"],
                "type": row["source_type"],
                **_decode_properties(row["source_properties"]),
            }
            target = {
                "id": row["target_id"],
                "name": row["target_name"],
                "type": row["target_type"],
                **_decode_properties(row["target_properties"]),
            }
            edges.append((source, row["relationship_name"], target))
        return edges

    async def _fetch_incident_edge_rows(self, node_id: str) -> list[dict[str, Any]]:
        """Read incident edges together with both endpoint nodes."""
        async with self.sessionmaker() as session:
            result = await session.execute(
                text("""
                    SELECT
                        source.id AS source_id,
                        source.name AS source_name,
                        source.type AS source_type,
                        source.properties AS source_properties,
                        edge.relationship_name,
                        edge.properties AS edge_properties,
                        target.id AS target_id,
                        target.name AS target_name,
                        target.type AS target_type,
                        target.properties AS target_properties
                    FROM graph_edge AS edge
                    JOIN graph_node AS source ON source.id = edge.source_id
                    JOIN graph_node AS target ON target.id = edge.target_id
                    WHERE edge.source_id = :node_id OR edge.target_id = :node_id
                """),
                {"node_id": node_id},
            )
            return list(result.mappings().all())

    async def get_neighbors(self, node_id: str) -> list[dict[str, Any]]:
        """Return unique incident neighbors, including the node for a self-loop."""
        requested_id = str(node_id)
        rows = await self._fetch_incident_edge_rows(requested_id)
        neighbors: dict[str, dict[str, Any]] = {}
        for row in rows:
            prefix = "target" if row["source_id"] == requested_id else "source"
            neighbor = {
                "id": row[f"{prefix}_id"],
                "name": row[f"{prefix}_name"],
                "type": row[f"{prefix}_type"],
                **_decode_properties(row[f"{prefix}_properties"]),
            }
            neighbors[neighbor["id"]] = neighbor
        return list(neighbors.values())

    async def get_connections(
        self, node_id: str | UUID
    ) -> list[tuple[dict[str, Any], dict[str, Any], dict[str, Any]]]:
        """Return every incident source-edge-target connection."""
        rows = await self._fetch_incident_edge_rows(str(node_id))
        connections = []
        for row in rows:
            source = {
                "id": row["source_id"],
                "name": row["source_name"],
                "type": row["source_type"],
                **_decode_properties(row["source_properties"]),
            }
            edge = {
                "relationship_name": row["relationship_name"],
                **_decode_properties(row["edge_properties"]),
            }
            target = {
                "id": row["target_id"],
                "name": row["target_name"],
                "type": row["target_type"],
                **_decode_properties(row["target_properties"]),
            }
            connections.append((source, edge, target))
        return connections

    @staticmethod
    async def _fetch_nodes_by_id(
        session: AsyncSession, node_ids: list[str]
    ) -> list[tuple[str, dict[str, Any]]]:
        if not node_ids:
            return []
        result = await session.execute(
            text("SELECT id, name, type, properties FROM graph_node WHERE id = ANY(:ids)"),
            {"ids": node_ids},
        )
        nodes = []
        for row in result.mappings().all():
            properties = {
                "name": row["name"],
                "type": row["type"],
                **_decode_properties(row["properties"]),
            }
            nodes.append((row["id"], properties))
        return nodes

    @staticmethod
    async def _fetch_edges_touching(
        session: AsyncSession, node_ids: list[str]
    ) -> list[tuple[str, str, str, dict[str, Any]]]:
        if not node_ids:
            return []
        result = await session.execute(
            text("""
                SELECT source_id, target_id, relationship_name, properties
                FROM graph_edge
                WHERE source_id = ANY(:ids) OR target_id = ANY(:ids)
            """),
            {"ids": node_ids},
        )
        return [
            (
                row["source_id"],
                row["target_id"],
                row["relationship_name"],
                _decode_properties(row["properties"]),
            )
            for row in result.mappings().all()
        ]

    @staticmethod
    async def _fetch_edges_within(
        session: AsyncSession, node_ids: list[str]
    ) -> list[tuple[str, str, str, dict[str, Any]]]:
        if not node_ids:
            return []
        result = await session.execute(
            text("""
                SELECT source_id, target_id, relationship_name, properties
                FROM graph_edge
                WHERE source_id = ANY(:ids) AND target_id = ANY(:ids)
            """),
            {"ids": node_ids},
        )
        return [
            (
                row["source_id"],
                row["target_id"],
                row["relationship_name"],
                _decode_properties(row["properties"]),
            )
            for row in result.mappings().all()
        ]

    async def get_entity_type_names(self, entity_ids: list[str]) -> dict[str, str]:
        """One-hop ``is_a`` lookup: entity id to its EntityType name."""
        if not entity_ids:
            return {}
        async with self.sessionmaker() as session:
            result = await session.execute(
                text(
                    """
                    SELECT e.source_id, t.name
                      FROM graph_edge e
                      JOIN graph_node t ON t.id = e.target_id
                     WHERE e.source_id = ANY(:ids)
                       AND e.relationship_name = 'is_a'
                       AND t.type = 'EntityType'
                    """
                ),
                {"ids": [str(entity_id) for entity_id in entity_ids]},
            )
            return {str(row[0]): row[1] for row in result.all() if row[1]}

    # Bound the aggregate to twice this many endpoint rows from one edge sample.
    _SEED_SAMPLE_ROWS = 200_000

    async def get_top_degree_node_ids(self, top_k: int) -> list[str]:
        """Approximate degree seeds from one bounded, materialized edge sample.

        An exact aggregate on the reported 5.59M-node / 35.6M-edge graph took
        57 seconds and spilled about 8.5 GB to temporary storage. Sampling
        bounds the aggregate without materializing the full graph in Python.

        The physical-prefix sample is not random: ingestion appends edges, so
        it can systematically miss recent hubs and stay anchored to early data
        as the graph grows. Both endpoints come from the SAME materialized
        sample. This is bounded approximate degree, not a freshness guarantee.
        A limited ID-only query fills sparse samples, including isolated nodes.
        """
        if top_k < 1:
            raise ValueError("top_k must be >= 1")

        async with self.sessionmaker() as session:
            result = await session.execute(
                text(
                    """
                    WITH sampled_edges AS MATERIALIZED (
                        SELECT source_id, target_id FROM graph_edge LIMIT :sample
                    )
                    SELECT node_id
                      FROM (
                            SELECT target_id AS node_id FROM sampled_edges
                             UNION ALL
                            SELECT source_id AS node_id FROM sampled_edges
                           ) endpoints
                     GROUP BY node_id
                     ORDER BY count(*) DESC, node_id
                     LIMIT :top_k
                    """
                ),
                {"sample": self._SEED_SAMPLE_ROWS, "top_k": top_k},
            )
            seed_ids = [str(row[0]) for row in result.all()]
            if len(seed_ids) < top_k:
                # Include isolated nodes when the edge sample cannot fill the
                # view. Fetch only missing ids, never full nodes or degrees.
                # ANY([]) intentionally matches nothing, so NOT includes every
                # node on an edgeless graph; asyncpg infers the array from id.
                result = await session.execute(
                    text(
                        "SELECT id FROM graph_node WHERE NOT (id = ANY(:seed_ids)) LIMIT :remaining"
                    ),
                    {"seed_ids": seed_ids, "remaining": top_k - len(seed_ids)},
                )
                return seed_ids + [str(row[0]) for row in result.all()]
            return seed_ids

    async def get_graph_data(
        self,
    ) -> tuple[list[tuple[str, dict[str, Any]]], list[tuple[str, str, str, dict[str, Any]]]]:
        """Return every node as (id, properties) and every edge as (source, target, name, props)."""
        async with self.sessionmaker() as session:
            node_result = await session.execute(
                text("SELECT id, name, type, properties FROM graph_node")
            )
            nodes = []
            for row in node_result.mappings().all():
                properties = {
                    "name": row["name"],
                    "type": row["type"],
                    **_decode_properties(row["properties"]),
                }
                nodes.append((row["id"], properties))
            if not nodes:
                return [], []

            edge_result = await session.execute(
                text("SELECT source_id, target_id, relationship_name, properties FROM graph_edge")
            )
            edges = [
                (
                    row["source_id"],
                    row["target_id"],
                    row["relationship_name"],
                    _decode_properties(row["properties"]),
                )
                for row in edge_result.mappings().all()
            ]
            return nodes, edges

    async def get_id_filtered_graph_data(
        self, target_ids: list[str]
    ) -> tuple[list[tuple[str, dict[str, Any]]], list[tuple[str, str, str, dict[str, Any]]]]:
        """Retrieve the subgraph touching target_ids: edges with either endpoint
        in the set, plus all endpoint nodes of those edges (edge-driven,
        matching the Ladybug/Neo4j contract). Lets CogneeGraph project only the
        vector-search neighborhood instead of the full graph.
        """
        if not target_ids:
            return [], []
        ids = [str(i) for i in target_ids]

        async with self.sessionmaker() as session:
            edges = await self._fetch_edges_touching(session, ids)
            endpoint_ids = {
                endpoint
                for source_id, target_id, _, _ in edges
                for endpoint in (source_id, target_id)
            }
            if not endpoint_ids:
                return [], []
            nodes = await self._fetch_nodes_by_id(session, list(endpoint_ids))
            return nodes, edges

    async def get_filtered_graph_data(
        self, attribute_filters: list[dict[str, list[str | int]]]
    ) -> tuple[list[tuple[str, dict]], list[tuple[str, str, str, dict]]]:
        """Return core-field matches and the edges induced by those nodes."""
        if not attribute_filters:
            return await self.get_graph_data()

        filters: list[tuple[str, set[str]]] = []
        for filter_dict in attribute_filters:
            for attr, filter_values in filter_dict.items():
                if attr not in self._ALLOWED_FILTER_ATTRS:
                    raise ValueError(f"Invalid filter attribute: {attr!r}")
                filters.append((attr, {str(value) for value in filter_values}))

        if not filters:
            return await self.get_graph_data()

        async with self.sessionmaker() as session:
            result = await session.execute(
                text("SELECT id, name, type, properties FROM graph_node")
            )
            nodes = []
            for row in result.mappings().all():
                if all(str(row[attribute]) in values for attribute, values in filters):
                    properties = {
                        "name": row["name"],
                        "type": row["type"],
                        **_decode_properties(row["properties"]),
                    }
                    nodes.append((row["id"], properties))

            edges = await self._fetch_edges_within(session, [node_id for node_id, _ in nodes])
            return nodes, edges

    async def get_nodeset_subgraph(
        self, node_type: type[Any], node_name: list[str], node_name_filter_operator: str = "OR"
    ) -> tuple[list[tuple[str, dict]], list[tuple[str, str, str, dict]]]:
        """Return matching primary nodes and their qualifying neighbors."""
        if node_name_filter_operator not in {"OR", "AND"}:
            raise ValueError("node_name_filter_operator must be 'OR' or 'AND'")
        if not node_name:
            return [], []

        async with self.sessionmaker() as session:
            result = await session.execute(
                text("SELECT id FROM graph_node WHERE type = :type AND name = ANY(:names)"),
                {"type": node_type.__name__, "names": [str(name) for name in node_name]},
            )
            primary_ids = {row["id"] for row in result.mappings().all()}
            if not primary_ids:
                return [], []

            incident_edges = await self._fetch_edges_touching(session, list(primary_ids))
            neighbor_ids = _select_nodeset_neighbor_ids(
                primary_ids,
                [(source_id, target_id) for source_id, target_id, _, _ in incident_edges],
                node_name_filter_operator,
            )
            subgraph_ids = list(primary_ids | neighbor_ids)
            nodes = await self._fetch_nodes_by_id(session, subgraph_ids)
            edges = await self._fetch_edges_within(session, subgraph_ids)
            return nodes, edges

    async def get_graph_counts(self) -> tuple[int, int]:
        """Count nodes and edges with two aggregation queries."""
        async with self.sessionmaker() as session:
            num_nodes = (await session.execute(text("SELECT count(*) FROM graph_node"))).scalar()
            num_edges = (await session.execute(text("SELECT count(*) FROM graph_edge"))).scalar()
        return num_nodes or 0, num_edges or 0

    async def get_graph_metrics(self, include_optional: bool = False) -> dict[str, Any]:
        """Compute the supported graph metrics in Python."""
        async with self.sessionmaker() as session:
            node_result = await session.execute(text("SELECT id FROM graph_node"))
            edge_result = await session.execute(text("SELECT source_id, target_id FROM graph_edge"))
            node_ids = [row["id"] for row in node_result.mappings().all()]
            edge_pairs = [
                (row["source_id"], row["target_id"]) for row in edge_result.mappings().all()
            ]
        num_nodes = len(node_ids)
        num_edges = len(edge_pairs)
        component_sizes = _component_sizes(node_ids, edge_pairs)

        return {
            "num_nodes": num_nodes,
            "num_edges": num_edges,
            "mean_degree": (2 * num_edges) / num_nodes if num_nodes else None,
            "edge_density": num_edges / (num_nodes * (num_nodes - 1)) if num_nodes > 1 else 0,
            "num_connected_components": len(component_sizes),
            "sizes_of_connected_components": component_sizes,
            "num_selfloops": sum(source == target for source, target in edge_pairs)
            if include_optional
            else -1,
            "diameter": -1,
            "avg_shortest_path_length": -1,
            "avg_clustering": -1,
        }

    async def get_neighborhood(
        self,
        node_ids: list[str],
        depth: int = 1,
        edge_types: list[str] | None = None,
    ) -> tuple[list[tuple[str, dict[str, Any]]], list[tuple[str, str, str, dict[str, Any]]]]:
        """Walk incident edges breadth-first and return the induced subgraph."""
        if depth < 0:
            raise ValueError("depth must be non-negative")
        if not node_ids:
            return [], []

        reached = {str(node_id) for node_id in node_ids}
        frontier = set(reached)
        unfiltered_hop = text("""
            SELECT source_id, target_id FROM graph_edge
            WHERE source_id = ANY(:ids) OR target_id = ANY(:ids)
        """)
        filtered_hop = text("""
            SELECT source_id, target_id FROM graph_edge
            WHERE (source_id = ANY(:ids) OR target_id = ANY(:ids))
              AND relationship_name = ANY(:edge_types)
        """)

        async with self.sessionmaker() as session:
            for _ in range(depth):
                if not frontier:
                    break
                params = {"ids": list(frontier)}
                statement = unfiltered_hop
                if edge_types:
                    statement = filtered_hop
                    params["edge_types"] = [str(edge_type) for edge_type in edge_types]
                result = await session.execute(statement, params)

                next_frontier = set()
                for row in result.mappings().all():
                    for endpoint in (row["source_id"], row["target_id"]):
                        if endpoint not in reached:
                            reached.add(endpoint)
                            next_frontier.add(endpoint)
                frontier = next_frontier

            subgraph_ids = list(reached)
            nodes = await self._fetch_nodes_by_id(session, subgraph_ids)
            edges = await self._fetch_edges_within(session, subgraph_ids)
            return nodes, edges

    # One hop of the bounded traversal. Each frontier node is read for at most
    # :max_nodes incident edges, since no node can use more than the whole
    # budget. New neighbours come back round robin: every frontier node's first
    # neighbour, then every second one, so one hub cannot take the budget.
    # Already-reached ids are dropped by the caller with a set: excluding them
    # here with `<> ALL(:reached)` is linear in the reached count (270 ms at
    # 4000 ids), and at most len(reached) candidates can be reached ones, so
    # :max_nodes candidates always leave enough.
    _BOUNDED_HOP = text("""
        SELECT candidate.neighbor_id
          FROM unnest(CAST(:frontier AS text[])) WITH ORDINALITY AS frontier(id, position)
         CROSS JOIN LATERAL (
               SELECT incident.neighbor_id, row_number() OVER () AS fan_out_rank
                 FROM (
                       SELECT target_id AS neighbor_id FROM graph_edge
                        WHERE source_id = frontier.id
                        UNION ALL
                       SELECT source_id FROM graph_edge
                        WHERE target_id = frontier.id
                        LIMIT :max_nodes
                      ) incident
               ) candidate
         GROUP BY candidate.neighbor_id
         ORDER BY min(candidate.fan_out_rank), min(frontier.position), candidate.neighbor_id
         LIMIT :max_nodes
    """)

    # Edges whose later endpoint is in this chunk: one endpoint in :chunk, the
    # other among the ids already handed out, this chunk included.
    _CHUNK_EDGES = text("""
        SELECT source_id, target_id, relationship_name, properties
          FROM graph_edge
         WHERE (source_id = ANY(:chunk) AND target_id = ANY(:emitted))
            OR (target_id = ANY(:chunk) AND source_id = ANY(:emitted))
    """)

    # Caps one query of a graph view, so a pathological read fails instead of
    # holding a pooled connection until pool_timeout.
    _BOUNDED_READ_TIMEOUT_MS = 15_000

    @asynccontextmanager
    async def _bounded_read_session(self):
        """A read session for ``iter_bounded_neighborhood``.

        Custom plans are forced because these queries bind id arrays: after
        five executions asyncpg's prepared statements move to a generic plan
        that no longer knows the array sizes, which made a 20k-node read 1.6x
        to 1.9x slower. Both settings end with the transaction.
        """
        async with self.sessionmaker() as session:
            await session.execute(text("SET LOCAL plan_cache_mode = force_custom_plan"))
            await session.execute(
                text(f"SET LOCAL statement_timeout = {self._BOUNDED_READ_TIMEOUT_MS}")
            )
            yield session

    async def iter_bounded_neighborhood(
        self,
        node_ids: list[str],
        depth: int,
        max_nodes: int,
        chunk_size: int = DEFAULT_NEIGHBORHOOD_CHUNK_SIZE,
        property_keys: list[str] | None = None,
    ) -> AsyncIterator[
        tuple[list[tuple[str, dict[str, Any]]], list[tuple[str, str, str, dict[str, Any]]]]
    ]:
        """Bounded breadth-first read in SQL, then node content one chunk at a time.

        Membership is ids only: one query per hop, stopping once ``max_nodes``
        ids are held. A hop returns at most ``len(frontier) * max_nodes``
        candidate rows, never the whole graph; under a bitmap plan the index
        scan still visits every index entry of a hub in the frontier, but heap
        reads stay within that bound. Each chunk then reads its nodes
        and the edges from them to nodes already handed out, in its own short
        session, so a slow consumer never holds a pooled connection between
        chunks. A chunk's edge read covers the incident edges of its nodes, so
        a hub costs its degree there, not the budget.
        """
        validate_bounded_neighborhood_args(depth, max_nodes, chunk_size)
        seed_ids = unique_node_ids(node_ids)
        if not seed_ids:
            return

        async with self._bounded_read_session() as session:
            members = await self._select_bounded_members(session, seed_ids, depth, max_nodes)

        emitted: list[str] = []
        for start in range(0, len(members), chunk_size):
            chunk_ids = members[start : start + chunk_size]
            async with self._bounded_read_session() as session:
                nodes = await self._fetch_member_nodes(session, chunk_ids, property_keys)
                if not nodes:
                    continue
                found_ids = [node_id for node_id, _ in nodes]
                emitted.extend(found_ids)
                result = await session.execute(
                    self._CHUNK_EDGES, {"chunk": found_ids, "emitted": emitted}
                )
                edges = [
                    (
                        row["source_id"],
                        row["target_id"],
                        row["relationship_name"],
                        _decode_properties(row["properties"]),
                    )
                    for row in result.mappings().all()
                ]
            yield nodes, edges

    async def _select_bounded_members(
        self, session: AsyncSession, seed_ids: list[str], depth: int, max_nodes: int
    ) -> list[str]:
        """Member ids in order: existing seeds, then each hop round robin."""
        result = await session.execute(
            text("SELECT id FROM graph_node WHERE id = ANY(:ids)"), {"ids": seed_ids}
        )
        existing = {row[0] for row in result.all()}
        members = [seed_id for seed_id in seed_ids if seed_id in existing][:max_nodes]
        reached = set(members)
        frontier = members
        for _ in range(depth):
            remaining = max_nodes - len(members)
            if not frontier or remaining < 1:
                break
            result = await session.execute(
                self._BOUNDED_HOP, {"frontier": frontier, "max_nodes": max_nodes}
            )
            frontier = [row[0] for row in result.all() if row[0] not in reached][:remaining]
            reached.update(frontier)
            members.extend(frontier)
        return members

    async def _fetch_member_nodes(
        self, session: AsyncSession, node_ids: list[str], property_keys: list[str] | None
    ) -> list[tuple[str, dict[str, Any]]]:
        """Nodes by id in ``node_ids`` order, optionally cut down to ``property_keys``."""
        if property_keys is None:
            nodes = await self._fetch_nodes_by_id(session, node_ids)
        else:
            # Projected in SQL, so large properties such as chunk text never leave
            # the database.
            result = await session.execute(
                text("""
                    SELECT id, name, type,
                           (SELECT jsonb_object_agg(key, value)
                              FROM jsonb_each(properties)
                             WHERE key = ANY(:keys)) AS properties
                      FROM graph_node
                     WHERE id = ANY(:ids)
                """),
                {"ids": node_ids, "keys": [str(key) for key in property_keys]},
            )
            nodes = [
                (
                    row["id"],
                    {
                        "name": row["name"],
                        "type": row["type"],
                        **_decode_properties(row["properties"]),
                    },
                )
                for row in result.mappings().all()
            ]
        position = {node_id: index for index, node_id in enumerate(node_ids)}
        return sorted(nodes, key=lambda node: position[node[0]])

    async def delete_graph(self) -> None:
        """Delete all nodes and edges from the graph."""
        await self.initialize()
        async with self._write_session() as session:
            await session.execute(text("TRUNCATE graph_edge, graph_node CASCADE"))
            await session.commit()

    # Provenance is stored in four text-array columns on both graph tables.

    async def _update_node_provenance(
        self,
        session: AsyncSession,
        node_ids: list[str],
        transition: Callable[[list[str], list[str]], ProvenanceColumns],
    ) -> None:
        """Lock each node and apply a provenance state transition."""
        lock = text("""
            SELECT source_ref_keys, source_run_refs
            FROM graph_node
            WHERE id = :id
            FOR UPDATE
        """)
        update = text("""
            UPDATE graph_node SET
                source_ref_keys = CAST(:source_ref_keys AS text[]),
                source_dataset_ids = CAST(:source_dataset_ids AS text[]),
                source_run_ids = CAST(:source_run_ids AS text[]),
                source_run_refs = CAST(:source_run_refs AS text[]),
                updated_at = now()
            WHERE id = :id
        """)
        for node_id in sorted({str(node_id) for node_id in node_ids}):
            result = await session.execute(lock, {"id": node_id})
            current = result.first()
            if current is None:
                continue
            updated = transition(list(current[0] or []), list(current[1] or []))
            await session.execute(
                update,
                {
                    "id": node_id,
                    "source_ref_keys": updated.source_ref_keys,
                    "source_dataset_ids": updated.source_dataset_ids,
                    "source_run_ids": updated.source_run_ids,
                    "source_run_refs": updated.source_run_refs,
                },
            )

    async def _update_edge_provenance(
        self,
        session: AsyncSession,
        edges: list[EdgeIdentity],
        transition: Callable[[list[str], list[str]], ProvenanceColumns],
    ) -> None:
        """Lock each edge and apply a provenance state transition."""
        lock = text("""
            SELECT source_ref_keys, source_run_refs
            FROM graph_edge
            WHERE source_id = :source_id
              AND target_id = :target_id
              AND relationship_name = :relationship_name
            FOR UPDATE
        """)
        update = text("""
            UPDATE graph_edge SET
                source_ref_keys = CAST(:source_ref_keys AS text[]),
                source_dataset_ids = CAST(:source_dataset_ids AS text[]),
                source_run_ids = CAST(:source_run_ids AS text[]),
                source_run_refs = CAST(:source_run_refs AS text[]),
                updated_at = now()
            WHERE source_id = :source_id
              AND target_id = :target_id
              AND relationship_name = :relationship_name
        """)
        for source_id, target_id, relationship_name in _edge_identities(edges):
            identity = {
                "source_id": source_id,
                "target_id": target_id,
                "relationship_name": relationship_name,
            }
            result = await session.execute(lock, identity)
            current = result.first()
            if current is None:
                continue
            updated = transition(list(current[0] or []), list(current[1] or []))
            await session.execute(
                update,
                {
                    **identity,
                    "source_ref_keys": updated.source_ref_keys,
                    "source_dataset_ids": updated.source_dataset_ids,
                    "source_run_ids": updated.source_run_ids,
                    "source_run_refs": updated.source_run_refs,
                },
            )

    async def attach_node_source_refs(
        self,
        node_ids: list[str],
        source_ref_keys: list[str],
        pipeline_run_id: str | None = None,
    ) -> None:
        if not source_ref_keys:
            return
        keys_to_add = list(source_ref_keys)
        async with self._write_session() as session:
            await self._update_node_provenance(
                session,
                node_ids,
                lambda keys, run_refs: provenance_after_attach(
                    keys, run_refs, keys_to_add, pipeline_run_id
                ),
            )
            await session.commit()

    async def attach_edge_source_refs(
        self,
        edges: list[EdgeIdentity],
        source_ref_keys: list[str],
        pipeline_run_id: str | None = None,
    ) -> None:
        if not source_ref_keys:
            return
        keys_to_add = list(source_ref_keys)
        async with self._write_session() as session:
            await self._update_edge_provenance(
                session,
                edges,
                lambda keys, run_refs: provenance_after_attach(
                    keys, run_refs, keys_to_add, pipeline_run_id
                ),
            )
            await session.commit()

    async def remove_node_source_refs(
        self,
        node_ids: list[str],
        source_ref_keys: list[str],
    ) -> None:
        if not source_ref_keys:
            return
        keys_to_remove = list(source_ref_keys)
        async with self._write_session() as session:
            await self._update_node_provenance(
                session,
                node_ids,
                lambda keys, run_refs: provenance_after_remove(keys, run_refs, keys_to_remove),
            )
            await session.commit()

    async def remove_edge_source_refs(
        self,
        edges: list[EdgeIdentity],
        source_ref_keys: list[str],
    ) -> None:
        if not source_ref_keys:
            return
        keys_to_remove = list(source_ref_keys)
        async with self._write_session() as session:
            await self._update_edge_provenance(
                session,
                edges,
                lambda keys, run_refs: provenance_after_remove(keys, run_refs, keys_to_remove),
            )
            await session.commit()

    async def delete_edge_triples(self, edges: list[EdgeIdentity]) -> None:
        """Delete edges by (source, target, relationship); keep the endpoint nodes."""
        if not edges:
            return
        statement = text("""
            DELETE FROM graph_edge
            WHERE source_id = :source_id
              AND target_id = :target_id
              AND relationship_name = :relationship_name
        """)
        async with self._write_session() as session:
            for source_id, target_id, relationship_name in _edge_identities(edges):
                await session.execute(
                    statement,
                    {
                        "source_id": source_id,
                        "target_id": target_id,
                        "relationship_name": relationship_name,
                    },
                )
            await session.commit()

    async def get_node_delete_data(self, node_ids: list[str]) -> dict[str, NodeDeleteData]:
        if not node_ids:
            return {}
        async with self.sessionmaker() as session:
            result = await session.execute(
                text("""
                    SELECT id, name, type, properties,
                           source_ref_keys, source_dataset_ids, source_run_ids, source_run_refs
                    FROM graph_node WHERE id = ANY(:ids)
                """),
                {"ids": [str(node_id) for node_id in node_ids]},
            )
            out: dict[str, NodeDeleteData] = {}
            for row in result.mappings().all():
                properties = _decode_properties(row["properties"])
                properties.update(id=row["id"], name=row["name"], type=row["type"])
                metadata = properties.get("metadata") or {}
                indexed_fields = (
                    list(metadata.get("index_fields") or []) if isinstance(metadata, dict) else []
                )
                out[row["id"]] = NodeDeleteData(
                    node_id=row["id"],
                    node_type=row["type"] or "",
                    indexed_fields=indexed_fields,
                    node_properties=properties,
                    source_ref_keys=list(row["source_ref_keys"] or []),
                    source_dataset_ids=list(row["source_dataset_ids"] or []),
                    source_run_ids=list(row["source_run_ids"] or []),
                    source_run_refs=list(row["source_run_refs"] or []),
                )
            return out

    async def get_edge_delete_data(
        self, edges: list[EdgeIdentity]
    ) -> dict[EdgeIdentity, EdgeDeleteData]:
        if not edges:
            return {}
        statement = text("""
            SELECT source_id, target_id, relationship_name, properties,
                   source_ref_keys, source_dataset_ids, source_run_ids, source_run_refs
            FROM graph_edge
            WHERE source_id = :source_id
              AND target_id = :target_id
              AND relationship_name = :relationship_name
        """)
        # Lazy import: prepare_edges_for_storage lives in the modules layer, whose
        # package __init__ imports get_graph_engine -> this adapter. Importing it at
        # module load would create a cycle; at delete-time it is safe.
        from cognee.modules.graph.utils.prepare_edges_for_storage import get_edge_retrieval_text

        out: dict[EdgeIdentity, EdgeDeleteData] = {}
        async with self.sessionmaker() as session:
            for source_id, target_id, relationship_name in _edge_identities(edges):
                result = await session.execute(
                    statement,
                    {
                        "source_id": source_id,
                        "target_id": target_id,
                        "relationship_name": relationship_name,
                    },
                )
                row = result.mappings().first()
                if row is None:
                    continue

                edge = EdgeIdentity(
                    source_id=row["source_id"],
                    target_id=row["target_id"],
                    relationship_name=row["relationship_name"],
                )
                properties = _decode_properties(row["properties"])
                out[edge] = EdgeDeleteData(
                    edge=edge,
                    edge_text=get_edge_retrieval_text(
                        properties.get("edge_text"), edge.relationship_name
                    ),
                    edge_properties=properties,
                    source_ref_keys=list(row["source_ref_keys"] or []),
                    source_dataset_ids=list(row["source_dataset_ids"] or []),
                    source_run_ids=list(row["source_run_ids"] or []),
                    source_run_refs=list(row["source_run_refs"] or []),
                )
        return out

    async def find_nodes_by_source_ref(self, source_ref_key: str) -> list[str]:
        async with self.sessionmaker() as session:
            result = await session.execute(
                text("SELECT id FROM graph_node WHERE :source_ref = ANY(source_ref_keys)"),
                {"source_ref": source_ref_key},
            )
            return [row["id"] for row in result.mappings().all()]

    async def find_edges_by_source_ref(self, source_ref_key: str) -> list[EdgeIdentity]:
        async with self.sessionmaker() as session:
            result = await session.execute(
                text("""
                    SELECT source_id, target_id, relationship_name
                    FROM graph_edge
                    WHERE :source_ref = ANY(source_ref_keys)
                """),
                {"source_ref": source_ref_key},
            )
            return [
                EdgeIdentity(
                    source_id=row["source_id"],
                    target_id=row["target_id"],
                    relationship_name=row["relationship_name"],
                )
                for row in result.mappings().all()
            ]

    async def find_node_source_refs_by_dataset(self, dataset_id: str) -> dict[str, list[str]]:
        dataset_id = str(dataset_id)
        async with self.sessionmaker() as session:
            result = await session.execute(
                text("""
                    SELECT id, source_ref_keys
                    FROM graph_node
                    WHERE :dataset_id = ANY(source_dataset_ids)
                """),
                {"dataset_id": dataset_id},
            )
            out: dict[str, list[str]] = {}
            for row in result.mappings().all():
                owned = [
                    key
                    for key in (row["source_ref_keys"] or [])
                    if str(get_dataset_id_from_source_ref_key(key)) == dataset_id
                ]
                if owned:
                    out[row["id"]] = owned
            return out

    async def find_edge_source_refs_by_dataset(
        self, dataset_id: str
    ) -> dict[EdgeIdentity, list[str]]:
        dataset_id = str(dataset_id)
        async with self.sessionmaker() as session:
            result = await session.execute(
                text("""
                    SELECT source_id, target_id, relationship_name, source_ref_keys
                    FROM graph_edge
                    WHERE :dataset_id = ANY(source_dataset_ids)
                """),
                {"dataset_id": dataset_id},
            )
            out: dict[EdgeIdentity, list[str]] = {}
            for row in result.mappings().all():
                owned = [
                    key
                    for key in (row["source_ref_keys"] or [])
                    if str(get_dataset_id_from_source_ref_key(key)) == dataset_id
                ]
                if owned:
                    edge = EdgeIdentity(
                        source_id=row["source_id"],
                        target_id=row["target_id"],
                        relationship_name=row["relationship_name"],
                    )
                    out[edge] = owned
            return out

    async def find_node_source_refs_by_pipeline_run(
        self, pipeline_run_id: str
    ) -> dict[str, list[str]]:
        pipeline_run_id = str(pipeline_run_id)
        async with self.sessionmaker() as session:
            result = await session.execute(
                text("""
                    SELECT id, source_run_refs
                    FROM graph_node
                    WHERE :pipeline_run_id = ANY(source_run_ids)
                """),
                {"pipeline_run_id": pipeline_run_id},
            )
            out: dict[str, list[str]] = {}
            for row in result.mappings().all():
                contributed = [
                    get_source_ref_key_from_source_run_ref(ref)
                    for ref in (row["source_run_refs"] or [])
                    if str(get_pipeline_run_id_from_source_run_ref(ref)) == pipeline_run_id
                ]
                if contributed:
                    out[row["id"]] = contributed
            return out

    async def find_edge_source_refs_by_pipeline_run(
        self, pipeline_run_id: str
    ) -> dict[EdgeIdentity, list[str]]:
        pipeline_run_id = str(pipeline_run_id)
        async with self.sessionmaker() as session:
            result = await session.execute(
                text("""
                    SELECT source_id, target_id, relationship_name, source_run_refs
                    FROM graph_edge
                    WHERE :pipeline_run_id = ANY(source_run_ids)
                """),
                {"pipeline_run_id": pipeline_run_id},
            )
            out: dict[EdgeIdentity, list[str]] = {}
            for row in result.mappings().all():
                contributed = [
                    get_source_ref_key_from_source_run_ref(ref)
                    for ref in (row["source_run_refs"] or [])
                    if str(get_pipeline_run_id_from_source_run_ref(ref)) == pipeline_run_id
                ]
                if contributed:
                    edge = EdgeIdentity(
                        source_id=row["source_id"],
                        target_id=row["target_id"],
                        relationship_name=row["relationship_name"],
                    )
                    out[edge] = contributed
            return out

    async def set_graph_metadata(self, metadata: dict[str, str]) -> None:
        """Upsert graph-level metadata keys."""
        if not metadata:
            return
        await self.initialize()
        rows = [{"key": str(key), "value": str(value)} for key, value in sorted(metadata.items())]
        upsert = text("""
            INSERT INTO graph_metadata (key, value)
            VALUES (:key, :value)
            ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value
        """)
        async with self._write_session() as session:
            await session.execute(upsert, rows)
            await session.commit()

    async def get_graph_metadata(self) -> dict[str, str]:
        """Return every graph-level metadata key and value."""
        await self.initialize()
        async with self.sessionmaker() as session:
            result = await session.execute(text("SELECT key, value FROM graph_metadata"))
            return {row["key"]: row["value"] for row in result.mappings().all()}

    async def remove_belongs_to_set_tags(
        self,
        tags: list[str],
        node_ids: list[str] | None = None,
    ) -> None:
        """Strip ``tags`` from each node's ``belongs_to_set`` property array.

        Keeps the denormalized membership list consistent with the additive
        belongs_to_set edges after a NodeSet (or its dataset) is deleted. The tags
        live inside the JSONB ``properties`` blob rather than in a core column, so
        this is a read-modify-write: the rows stay locked in node-id order for the
        whole transaction so a concurrent cleanup cannot overwrite this one.
        """
        if not tags:
            return
        if node_ids is not None and not node_ids:
            return

        tags_to_remove = set(tags)
        select_scoped = text("""
            SELECT id, properties FROM graph_node
            WHERE id = ANY(:ids)
            ORDER BY id
            FOR UPDATE
        """)
        select_all = text("SELECT id, properties FROM graph_node ORDER BY id FOR UPDATE")
        update_properties = text("""
            UPDATE graph_node
            SET properties = CAST(:properties AS jsonb), updated_at = now()
            WHERE id = :id
        """)

        async with self._write_session() as session:
            if node_ids is None:
                result = await session.execute(select_all)
            else:
                result = await session.execute(
                    select_scoped, {"ids": [str(node_id) for node_id in node_ids]}
                )

            for row in result.mappings().all():
                properties = _decode_properties(row["properties"])
                current_tags = properties.get("belongs_to_set")
                if not isinstance(current_tags, list) or tags_to_remove.isdisjoint(current_tags):
                    continue
                properties["belongs_to_set"] = [
                    tag for tag in current_tags if tag not in tags_to_remove
                ]
                await session.execute(
                    update_properties,
                    {
                        "id": row["id"],
                        "properties": json.dumps(properties, cls=JSONEncoder),
                    },
                )
            await session.commit()

    async def get_triplets_batch(self, offset: int, limit: int) -> list[dict[str, Any]]:
        """Return one page of source-edge-target triplets.

        Ordering by the full edge identity keeps pagination stable, so exporting
        the graph page by page visits every triplet exactly once.
        """
        if offset < 0:
            raise ValueError(f"Offset must be non-negative, got {offset}")
        if limit < 0:
            raise ValueError(f"Limit must be non-negative, got {limit}")

        async with self.sessionmaker() as session:
            result = await session.execute(
                text("""
                    SELECT
                        source.id AS source_id,
                        source.name AS source_name,
                        source.type AS source_type,
                        source.properties AS source_properties,
                        edge.relationship_name,
                        edge.properties AS edge_properties,
                        target.id AS target_id,
                        target.name AS target_name,
                        target.type AS target_type,
                        target.properties AS target_properties
                    FROM graph_edge AS edge
                    JOIN graph_node AS source ON source.id = edge.source_id
                    JOIN graph_node AS target ON target.id = edge.target_id
                    ORDER BY edge.source_id, edge.target_id, edge.relationship_name
                    OFFSET :offset LIMIT :limit
                """),
                {"offset": offset, "limit": limit},
            )

            return [
                {
                    "start_node": {
                        "id": row["source_id"],
                        "name": row["source_name"],
                        "type": row["source_type"],
                        **_decode_properties(row["source_properties"]),
                    },
                    "relationship_properties": {
                        "relationship_name": row["relationship_name"],
                        **_decode_properties(row["edge_properties"]),
                    },
                    "end_node": {
                        "id": row["target_id"],
                        "name": row["target_name"],
                        "type": row["target_type"],
                        **_decode_properties(row["target_properties"]),
                    },
                }
                for row in result.mappings().all()
            ]

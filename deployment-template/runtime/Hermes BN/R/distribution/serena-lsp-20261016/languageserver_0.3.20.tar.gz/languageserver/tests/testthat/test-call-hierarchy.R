test_that("Call hierarchy works in single file", {
    skip_on_cran()
    client <- language_client()

    single_file <- withr::local_tempfile(fileext = ".R")
    writeLines(c(
        "foo <- function(x) { x + 1 }",
        "bar <- function(x) { foo(x) + 1 }",
        "fun <- function(x) { foo(x) + bar(x) + 1 }"
    ), single_file)

    client %>% did_open(single_file)

    result <- client %>% respond_prepare_call_hierarchy(
        single_file, c(0, 1), retry_when = function(result) length(result) == 0)

    expect_length(result, 1)
    expect_equal(result[[1]]$name, "foo")
    expect_equal(result[[1]]$kind, SymbolKind$Function)
    expect_equal(result[[1]]$uri, path_to_uri(single_file))
    expect_equal(result[[1]]$range, list(
        start = list(line = 0, character = 0),
        end = list(line = 0, character = 28)
    ))
    expect_equal(result[[1]]$selectionRange, list(
        start = list(line = 0, character = 0),
        end = list(line = 0, character = 28)
    ))

    result <- client %>% respond_prepare_call_hierarchy(
        single_file, c(1, 22), retry_when = function(result) length(result) == 0)
    expect_length(result, 1)
    expect_equal(result[[1]]$name, "foo")
    expect_equal(result[[1]]$kind, SymbolKind$Function)
    expect_equal(result[[1]]$uri, path_to_uri(single_file))
    expect_equal(result[[1]]$range, list(
        start = list(line = 0, character = 0),
        end = list(line = 0, character = 28)
    ))
    expect_equal(result[[1]]$selectionRange, list(
        start = list(line = 0, character = 0),
        end = list(line = 0, character = 28)
    ))

    result <- client %>% respond_prepare_call_hierarchy(
        single_file, c(2, 32), retry_when = function(result) length(result) == 0)
    expect_length(result, 1)
    expect_equal(result[[1]]$name, "bar")
    expect_equal(result[[1]]$kind, SymbolKind$Function)
    expect_equal(result[[1]]$uri, path_to_uri(single_file))
    expect_equal(result[[1]]$range, list(
        start = list(line = 1, character = 0),
        end = list(line = 1, character = 33)
    ))
    expect_equal(result[[1]]$selectionRange, list(
        start = list(line = 1, character = 0),
        end = list(line = 1, character = 33)
    ))
})

test_that("Call hierarchy works in multiple files", {
    skip_on_cran()
    client <- language_client()

    file1 <- withr::local_tempfile(fileext = ".R")
    file2 <- withr::local_tempfile(fileext = ".R")

    writeLines(c(
        "foo <- function(x) { x + 1 }",
        "bar <- function(x) { foo(x) + 1 }"
    ), file1)

    writeLines(c(
        "fun <- function(x) { foo(x) + bar(x) + 1 }"
    ), file2)

    client %>% did_open(file1)
    client %>% did_open(file2)

    result <- client %>% respond_prepare_call_hierarchy(
        file2, c(0, 22), retry_when = function(result) length(result) == 0)

    expect_length(result, 1)
    expect_equal(result[[1]]$name, "foo")
    expect_equal(result[[1]]$kind, SymbolKind$Function)
    expect_equal(result[[1]]$uri, path_to_uri(file1))
    expect_equal(result[[1]]$range, list(
        start = list(line = 0, character = 0),
        end = list(line = 0, character = 28)
    ))
    expect_equal(result[[1]]$selectionRange, list(
        start = list(line = 0, character = 0),
        end = list(line = 0, character = 28)
    ))

    result <- client %>% respond_prepare_call_hierarchy(
        file2, c(0, 32), retry_when = function(result) length(result) == 0)
    expect_length(result, 1)
    expect_equal(result[[1]]$name, "bar")
    expect_equal(result[[1]]$kind, SymbolKind$Function)
    expect_equal(result[[1]]$uri, path_to_uri(file1))
    expect_equal(result[[1]]$range, list(
        start = list(line = 1, character = 0),
        end = list(line = 1, character = 33)
    ))
    expect_equal(result[[1]]$selectionRange, list(
        start = list(line = 1, character = 0),
        end = list(line = 1, character = 33)
    ))
})

test_that("Call hierarchy incoming calls works", {
    skip_on_cran()
    client <- language_client()

    single_file <- withr::local_tempfile(fileext = ".R")
    writeLines(c(
        "foo <- function(x) { x + 1 }",
        "bar <- function(x) { foo(x) + 1 }",
        "fun <- function(x) { foo(x) + bar(x) + foo(bar(x)) }"
    ), single_file)

    client %>% did_open(single_file)

    items <- client %>% respond_prepare_call_hierarchy(
        single_file, c(0, 1), retry_when = function(result) length(result) == 0)

    result <- client %>% respond_call_hierarchy_incoming_calls(
        items[[1]], retry_when = function(result) length(result) == 0)

    expect_length(result, 2)

    result1 <- result %>% keep(~ .$from$name == "bar")
    expect_equal(result1[[1]]$from$name, "bar")
    expect_equal(result1[[1]]$from$kind, SymbolKind$Function)
    expect_equal(result1[[1]]$from$uri, path_to_uri(single_file))
    expect_equal(result1[[1]]$from$range, list(
        start = list(line = 1, character = 0),
        end = list(line = 1, character = 33)
    ))
    expect_equal(result1[[1]]$from$selectionRange, list(
        start = list(line = 1, character = 0),
        end = list(line = 1, character = 33)
    ))
    expect_length(result1[[1]]$fromRanges, 1)
    expect_equal(result1[[1]]$fromRanges[[1]], list(
        start = list(line = 1, character = 21),
        end = list(line = 1, character = 24)
    ))

    result2 <- result %>% keep(~ .$from$name == "fun")
    expect_equal(result2[[1]]$from$name, "fun")
    expect_equal(result2[[1]]$from$kind, SymbolKind$Function)
    expect_equal(result2[[1]]$from$uri, path_to_uri(single_file))
    expect_equal(result2[[1]]$from$range, list(
        start = list(line = 2, character = 0),
        end = list(line = 2, character = 52)
    ))
    expect_equal(result2[[1]]$from$selectionRange, list(
        start = list(line = 2, character = 0),
        end = list(line = 2, character = 52)
    ))
    expect_length(result2[[1]]$fromRanges, 2)
    expect_equal(result2[[1]]$fromRanges[[1]], list(
        start = list(line = 2, character = 21),
        end = list(line = 2, character = 24)
    ))
    expect_equal(result2[[1]]$fromRanges[[2]], list(
        start = list(line = 2, character = 39),
        end = list(line = 2, character = 42)
    ))
})


test_that("Call hierarchy outgoing calls works", {
    skip_on_cran()
    client <- language_client()

    single_file <- withr::local_tempfile(fileext = ".R")
    writeLines(c(
        "foo <- function(x) { x + 1 }",
        "bar <- function(x) { foo(x) + 1 }",
        "fun <- function(x) { foo(x) + bar(x) + foo(bar(x)) }"
    ), single_file)

    client %>% did_open(single_file)

    items <- client %>% respond_prepare_call_hierarchy(
        single_file, c(2, 1), retry_when = function(result) length(result) == 0)

    result <- client %>% respond_call_hierarchy_outgoing_calls(
        items[[1]], retry_when = function(result) length(result) == 0)

    expect_length(result, 2)

    result1 <- result %>% keep(~ .$to$name == "foo")

    expect_equal(result1[[1]]$to$name, "foo")
    expect_equal(result1[[1]]$to$kind, SymbolKind$Function)
    expect_equal(result1[[1]]$to$uri, path_to_uri(single_file))
    expect_equal(result1[[1]]$to$range, list(
        start = list(line = 0, character = 0),
        end = list(line = 0, character = 28)
    ))
    expect_equal(result1[[1]]$to$selectionRange, list(
        start = list(line = 0, character = 0),
        end = list(line = 0, character = 28)
    ))
    expect_length(result1[[1]]$fromRanges, 2)
    expect_equal(result1[[1]]$fromRanges[[1]], list(
        start = list(line = 2, character = 21),
        end = list(line = 2, character = 24)
    ))
    expect_equal(result1[[1]]$fromRanges[[2]], list(
        start = list(line = 2, character = 39),
        end = list(line = 2, character = 42)
    ))

    result2 <- result %>% keep(~ .$to$name == "bar")
    expect_equal(result2[[1]]$to$name, "bar")
    expect_equal(result2[[1]]$to$kind, SymbolKind$Function)
    expect_equal(result2[[1]]$to$uri, path_to_uri(single_file))
    expect_equal(result2[[1]]$to$range, list(
        start = list(line = 1, character = 0),
        end = list(line = 1, character = 33)
    ))
    expect_equal(result2[[1]]$to$selectionRange, list(
        start = list(line = 1, character = 0),
        end = list(line = 1, character = 33)
    ))
    expect_length(result2[[1]]$fromRanges, 2)
    expect_equal(result2[[1]]$fromRanges[[1]], list(
        start = list(line = 2, character = 30),
        end = list(line = 2, character = 33)
    ))
    expect_equal(result2[[1]]$fromRanges[[2]], list(
        start = list(line = 2, character = 43),
        end = list(line = 2, character = 46)
    ))
})

legacy_call_hierarchy_fixture <- function() {
    content <- c(
        "target <- function() 1",
        "caller <- function() { target(); target() }",
        "target()"
    )
    uri <- "file:///legacy-call-hierarchy.R"
    document <- Document$new(uri, version = 1L, content = content)
    parse_data <- parse_document(uri, content)
    parse_data$xml_doc <- xml2::read_xml(parse_data$xml_data)
    parse_data$reference_index <- NULL
    document$update_parse_data(parse_data)

    documents <- collections::dict()
    documents$set(uri, document)
    workspace <- new.env(parent = baseenv())
    workspace$documents <- documents
    workspace$get_parse_data <- function(request_uri) {
        stopifnot(identical(request_uri, uri))
        parse_data
    }
    workspace$get_definitions_for_uri <- function(request_uri) {
        stopifnot(identical(request_uri, uri))
        unname(parse_data$definitions)
    }
    workspace$get_definition <- function(...) NULL

    list(
        uri = uri,
        document = document,
        workspace = workspace,
        definitions = parse_data$definitions
    )
}

test_that("Call hierarchy falls back to XML for outgoing calls", {
    fixture <- legacy_call_hierarchy_fixture()
    definition <- fixture$definitions$caller
    item <- list(
        name = "caller",
        uri = fixture$uri,
        range = definition$range,
        data = list(definition = list(
            uri = fixture$uri,
            range = definition$range
        ))
    )

    reply <- call_hierarchy_outgoing_calls_reply(
        1L, fixture$workspace, item
    )

    expect_length(reply$result, 1L)
    expect_equal(reply$result[[1L]]$to$name, "target")
    expect_equal(reply$result[[1L]]$to$uri, fixture$uri)
    expect_length(reply$result[[1L]]$fromRanges, 2L)
    expect_equal(
        map_int(reply$result[[1L]]$fromRanges, c("start", "line")),
        c(1L, 1L)
    )
})

test_that("Call hierarchy falls back to XML for incoming calls", {
    fixture <- legacy_call_hierarchy_fixture()
    definition <- fixture$definitions$target
    item <- list(
        name = "target",
        uri = fixture$uri,
        range = definition$range,
        data = list(definition = list(
            uri = fixture$uri,
            range = definition$range
        ))
    )

    reply <- call_hierarchy_incoming_calls_reply(
        1L, fixture$workspace, item
    )

    expect_length(reply$result, 2L)
    caller <- keep(reply$result, ~ .$from$name == "caller")[[1L]]
    expect_equal(caller$from$kind, SymbolKind$Function)
    expect_length(caller$fromRanges, 2L)
    expect_equal(
        map_int(caller$fromRanges, c("start", "character")),
        c(23L, 33L)
    )
    top_level <- keep(
        reply$result, ~ .$from$name == "legacy-call-hierarchy.R")[[1L]]
    expect_equal(top_level$from$kind, SymbolKind$File)
    expect_equal(top_level$from$detail, "top level")
    expect_equal(top_level$fromRanges[[1L]]$start$line, 2L)
})

"""FastAPI server for the Cognee API."""

import os
from contextlib import asynccontextmanager
from traceback import format_exc

import uvicorn
from fastapi import FastAPI, Request, status
from fastapi.encoders import jsonable_encoder
from fastapi.exception_handlers import http_exception_handler
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

# Registers the GitHub and Linear integrations with the integrations registry
# as import side effects. Slack registers via its router imports above; GitHub
# and Linear mount no routers of their own (webhooks arrive on the generic
# /api/v1/integrations/{provider}/events routes), so the registration imports
# are explicit here.
import cognee.modules.integrations.github
import cognee.modules.integrations.gmail
import cognee.modules.integrations.google_drive
import cognee.modules.integrations.linear
from cognee.api.exception_telemetry import send_api_exception_telemetry
from cognee.api.startup_checks import report_default_user_login_posture
from cognee.api.v1.activity.routers import get_activity_router
from cognee.api.v1.add.routers import get_add_router
from cognee.api.v1.agents.routers import get_agents_router
from cognee.api.v1.api_keys.routers import get_api_key_management_router
from cognee.api.v1.cloud.routers import get_checks_router
from cognee.api.v1.cognify.routers import get_cognify_router
from cognee.api.v1.datasets.routers import get_datasets_router
from cognee.api.v1.delete.routers import get_delete_router
from cognee.api.v1.forget.routers import get_forget_router
from cognee.api.v1.health.routers import get_health_router
from cognee.api.v1.improve.routers import get_improve_router
from cognee.api.v1.integrations.routers import get_integrations_router
from cognee.api.v1.llm.routers import get_llm_router
from cognee.api.v1.memify.routers import get_memify_router
from cognee.api.v1.ontologies.routers.get_ontology_router import get_ontology_router
from cognee.api.v1.permissions.routers import get_permissions_router
from cognee.api.v1.proposals.routers import get_proposals_router
from cognee.api.v1.recall.routers import get_recall_router
from cognee.api.v1.remember.routers import get_remember_router
from cognee.api.v1.responses.routers import get_responses_router
from cognee.api.v1.search.routers import get_search_router
from cognee.api.v1.sessions import get_sessions_router
from cognee.api.v1.settings.routers import get_settings_router
from cognee.api.v1.skills.routers import get_skills_router
from cognee.api.v1.slack.routers import get_slack_channels_router, get_slack_router
from cognee.api.v1.sync.routers import get_sync_router
from cognee.api.v1.update.routers import get_update_router
from cognee.api.v1.users.routers import (
    get_auth_router,
    get_configuration_router,
    get_register_router,
    get_reset_password_router,
    get_user_id_by_email_router,
    get_users_router,
    get_verify_router,
    get_visualize_router,
)
from cognee.api.v1.validate.routers import get_validate_router
from cognee.api.v1.visualize.routers import get_schema_router
from cognee.exceptions import CogneeApiError, remediation_for
from cognee.modules.users.authentication.redact_websocket_query_secrets import (
    install_websocket_query_param_redaction,
)
from cognee.modules.users.methods.get_authenticated_user import (
    _AUTH_REASON,
    REQUIRE_AUTHENTICATION,
)
from cognee.shared.logging_utils import get_logger, setup_logging

# Ensure application logging is configured for container stdout/stderr
setup_logging()
logger = get_logger()

# Keeps the WebSocket ?token= auth fallback out of uvicorn's own access/error
# logs, regardless of how uvicorn was launched (this module is imported
# either way). See redact_websocket_query_secrets.py for why this can't be
# left to proxy-side redaction alone.
install_websocket_query_param_redaction()

app_environment = os.getenv("ENV", "prod")

# How long the shutdown hook waits for background tasks (B6). The default must
# fit inside the smallest shipped kill window WITH room left for the engine
# close below it: compose ships stop_grace_period: 15s (bare docker stops at
# 10s), so a longer drain gets the worker SIGKILLed mid-WAL-checkpoint — the
# exact failure the close exists to prevent. Raise this together with the
# stop timeout (K8s/gunicorn default 30s).
BACKGROUND_DRAIN_TIMEOUT_SECONDS = float(os.getenv("BACKGROUND_DRAIN_TIMEOUT_SECONDS", "8"))


@asynccontextmanager
async def lifespan(app: FastAPI):
    # from cognee.modules.data.deletion import prune_system, prune_data
    # await prune_data()
    # await prune_system(metadata = True)
    # if app_environment == "local" or app_environment == "dev":
    from cognee.infrastructure.databases.relational import get_relational_engine
    from cognee.run_migrations import run_migrations

    try:
        await run_migrations()
    except Exception:
        logger.debug("Ignoring exception in lifespan", exc_info=True)
        db_engine = get_relational_engine()
        await db_engine.create_database()

        await run_migrations()

    from cognee.base_config import get_base_config
    from cognee.modules.users.methods import get_default_user

    # Submodule import on purpose: the package re-exports these names, and a
    # test that imports a sibling SUBMODULE (get_authenticated_user) shadows the
    # re-export with the module object, breaking later `Depends()` lookups.
    from cognee.modules.users.methods.set_default_user_password_if_unset import (
        set_default_user_password_if_unset,
    )

    # The server creates the default user only when asked to make it loginable.
    # Unset, it creates nothing: a server nobody configured has no default
    # account to attack. (The SDK and CLI still create it lazily, in-process,
    # with no password -- see create_default_user.) When set, the password is
    # applied ONCE to a password-less account and never to one that already
    # has a password.
    if get_base_config().default_user_password:
        await get_default_user()
        await set_default_user_password_if_unset()
    report_default_user_login_posture()
    from cognee.modules.cognify.recovery import pipeline_recovery_service
    from cognee.modules.users.authentication.get_auth_secret import resolve_auth_secrets

    # Warns at startup, not on the first login, when a token secret was generated.
    resolve_auth_secrets()
    # Fail the boot, not every later request: a bad IMPROVE_* value (an
    # IMPROVE_STAGES_DISABLED typo, an out-of-range alpha) raises here with the
    # full message instead of surfacing as a generic 409 per improve call.
    from cognee.modules.improve import get_improve_config

    get_improve_config()

    # Emit a clear startup message for docker logs
    logger.info("Backend server has started")

    async with pipeline_recovery_service():
        yield

    # Let in-flight background work (background remember runs, the session
    # improve bridge) finish before the engines below are torn down under it.
    # Bounded so a stuck task cannot hold the process hostage; nothing is
    # cancelled on timeout, it is only reported.
    from cognee.infrastructure.background_tasks import wait_for_background_tasks

    logger.info("Shutting down: draining background tasks")
    if not await wait_for_background_tasks(timeout=BACKGROUND_DRAIN_TIMEOUT_SECONDS):
        logger.warning(
            "Shutting down with background tasks still running after %.0fs",
            BACKGROUND_DRAIN_TIMEOUT_SECONDS,
        )

    # Flush and close all cached database adapters so Ladybug can
    # CHECKPOINT its WAL before the process exits.  Without this,
    # a SIGTERM during an active WAL write leaves a half-written
    # record on disk → "Corrupted wal file" on next startup.
    logger.info("Shutting down: closing cached database engines")
    from cognee.infrastructure.databases.graph.get_graph_engine import _create_graph_engine
    from cognee.infrastructure.databases.vector.create_vector_engine import (
        _create_vector_engine,
    )

    _create_graph_engine.cache_clear()
    _create_vector_engine.cache_clear()

    # Flush in-flight telemetry and close its shared aiohttp session on the
    # loop that owns them, instead of leaving it to the atexit fallback.
    from cognee.shared.utils import close_telemetry_session

    await close_telemetry_session()


app = FastAPI(debug=app_environment != "prod", lifespan=lifespan)


@app.middleware("http")
async def _report_unhandled_exceptions(request, call_next):
    # Exceptions a registered handler claims (CogneeApiError,
    # RequestValidationError) are turned into responses by Starlette's
    # ExceptionMiddleware, which sits INSIDE this one -- so they arrive here as
    # ordinary responses and are not double-counted. What reaches this except
    # is what no handler claimed: the genuine crashes that become a bare 500,
    # and the ones most worth seeing. Re-raised untouched so the response is
    # byte-for-byte what it is today.
    try:
        return await call_next(request)
    except Exception as error:
        send_api_exception_telemetry(request, error, status.HTTP_500_INTERNAL_SERVER_ERROR)
        raise


@app.middleware("http")
async def _stamp_operation_origin(request, call_next):
    # Operations executed for this request record origin="api" in
    # pipeline_runs. ContextVars set here propagate into the handler task.
    from cognee.modules.operations import ORIGIN_API, operation_origin_scope

    with operation_origin_scope(ORIGIN_API):
        return await call_next(request)


# Read allowed origins from environment variable (comma-separated)
CORS_ALLOWED_ORIGINS = os.getenv("CORS_ALLOWED_ORIGINS")
if CORS_ALLOWED_ORIGINS:
    allowed_origins = [
        origin.strip() for origin in CORS_ALLOWED_ORIGINS.split(",") if origin.strip()
    ]
else:
    allowed_origins = [
        os.getenv("UI_APP_URL", "http://localhost:3000"),
    ]  # Block all except explicitly set origins

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,  # Now controlled by env var
    allow_credentials=True,
    allow_methods=["OPTIONS", "GET", "PUT", "POST", "DELETE"],
    allow_headers=["*"],
)
# To allow origins, set CORS_ALLOWED_ORIGINS env variable to a comma-separated list, e.g.:
# CORS_ALLOWED_ORIGINS="https://yourdomain.com,https://another.com"


def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title="Cognee API",
        version="1.0.0",
        description="Cognee API with Bearer token and Cookie auth",
        routes=app.routes,
    )

    # Define security schemes with valid identifiers (no hyphens)
    openapi_schema["components"]["securitySchemes"] = {
        "ApiKeyAuth": {"type": "apiKey", "in": "header", "name": "X-Api-Key"},
        "BearerAuth": {"type": "http", "scheme": "bearer"},
    }

    our_security = [{"BearerAuth": []}, {"ApiKeyAuth": []}]

    if REQUIRE_AUTHENTICATION:
        # Set global security fallback
        openapi_schema["security"] = our_security

        # Replace per-operation security refs auto-generated by fastapi-users
        # (they reference internal names like OAuth2PasswordBearer, APIKeyHeader, APIKeyCookie
        # which no longer exist after we replaced securitySchemes above)
        for path_data in openapi_schema.get("paths", {}).values():
            for operation in path_data.values():
                if isinstance(operation, dict) and "security" in operation:
                    operation["security"] = our_security

    app.openapi_schema = openapi_schema

    return app.openapi_schema


app.openapi = custom_openapi


@app.exception_handler(RequestValidationError)
async def request_validation_exception_handler(request: Request, exc: RequestValidationError):
    send_api_exception_telemetry(request, exc, status.HTTP_400_BAD_REQUEST)

    if request.url.path == "/api/v1/auth/login":
        return JSONResponse(
            status_code=400,
            content={"detail": "LOGIN_BAD_CREDENTIALS"},
        )

    return JSONResponse(
        status_code=400,
        content=jsonable_encoder({"detail": exc.errors(), "body": exc.body}),
    )


# fastapi-users rejects an unauthenticated request with a bare
# ``HTTPException(401)`` whose detail is the stock "Unauthorized" — it says
# nothing about WHY authentication is on (with no env vars set the posture
# defaults to multi-tenant, so a fresh ``docker run`` 401s on every /api/v1
# call with no explanation). Enrich exactly that generic body with the
# posture already resolved at startup so the caller can fix it without
# reading the source. 401s that carry a specific detail (e.g.
# LOGIN_BAD_CREDENTIALS on /auth/login) pass through untouched.
GENERIC_401_HELP = (
    f"Authentication required (auth posture: {_AUTH_REASON}). "
    "For single-user local use, set ENABLE_BACKEND_ACCESS_CONTROL=false and restart. "
    "To keep authentication and log in instead, set DEFAULT_USER_PASSWORD to make the "
    "default account loginable — see docs/minimal-docker-compose.md."
)


@app.exception_handler(StarletteHTTPException)
async def explain_generic_401(request: Request, exc: StarletteHTTPException):
    if (
        exc.status_code == status.HTTP_401_UNAUTHORIZED
        and exc.detail in (None, "Unauthorized")
        and request.url.path.startswith("/api/v1/")
    ):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": GENERIC_401_HELP},
            headers=getattr(exc, "headers", None),
        )
    # Everything else keeps FastAPI's stock HTTPException behavior.
    return await http_exception_handler(request, exc)


@app.exception_handler(CogneeApiError)
async def exception_handler(request: Request, exc: CogneeApiError) -> JSONResponse:
    detail = {}
    improperly_defined = False

    if exc.name and exc.message and exc.status_code:
        status_code = exc.status_code
        detail["message"] = f"{exc.message} [{exc.name}]"
    else:
        # Log an error indicating the exception is improperly defined
        improperly_defined = True
        logger.error("Improperly defined exception: %s", exc)
        # Provide a default error response
        detail["message"] = "An unexpected error occurred."
        status_code = status.HTTP_500_INTERNAL_SERVER_ERROR

    # log the stack trace for easier serverside debugging
    logger.error(format_exc())
    send_api_exception_telemetry(
        request,
        exc,
        status_code,
        error_name=exc.name if not improperly_defined else None,
        improperly_defined=improperly_defined,
    )
    content = {"detail": detail["message"]}
    # A hint the caller can act on: the exception's own remediation first, else the
    # shared first-run table. Only present when a fix is known, so existing clients
    # that read only `detail` are unaffected.
    remediation = remediation_for(exc)
    if remediation:
        content["remediation"] = remediation
    return JSONResponse(status_code=status_code, content=content)


app.include_router(get_auth_router(), prefix="/api/v1/auth", tags=["auth"])

app.include_router(
    get_register_router(),
    prefix="/api/v1/auth",
    tags=["auth"],
)

app.include_router(
    get_reset_password_router(),
    prefix="/api/v1/auth",
    tags=["auth"],
)

app.include_router(
    get_verify_router(),
    prefix="/api/v1/auth",
    tags=["auth"],
)

app.include_router(get_api_key_management_router(), prefix="/api/v1/auth", tags=["auth"])

app.include_router(get_add_router(), prefix="/api/v1/add", tags=["add"])

app.include_router(get_cognify_router(), prefix="/api/v1/cognify", tags=["cognify"])

app.include_router(get_memify_router(), prefix="/api/v1/memify", tags=["memify"])

app.include_router(get_search_router(), prefix="/api/v1/search", tags=["search"])

app.include_router(
    get_permissions_router(),
    prefix="/api/v1/permissions",
    tags=["permissions"],
)

app.include_router(get_datasets_router(), prefix="/api/v1/datasets", tags=["datasets"])

app.include_router(get_ontology_router(), prefix="/api/v1/ontologies", tags=["ontologies"])

app.include_router(get_settings_router(), prefix="/api/v1/settings", tags=["settings"])

app.include_router(get_visualize_router(), prefix="/api/v1/visualize", tags=["visualize"])

app.include_router(get_schema_router(), prefix="/api/v1/schema", tags=["schema"])

app.include_router(get_skills_router(), prefix="/api/v1/skills", tags=["skills"])
app.include_router(get_proposals_router(), prefix="/api/v1/proposals", tags=["skills"])

app.include_router(
    get_configuration_router(),
    prefix="/api/v1/configuration",
    tags=["configuration"],
)

app.include_router(get_delete_router(), prefix="/api/v1/delete", tags=["delete"])

app.include_router(get_validate_router(), prefix="/api/v1/validate", tags=["validate"])

app.include_router(get_update_router(), prefix="/api/v1/update", tags=["update"])

app.include_router(get_responses_router(), prefix="/api/v1/responses", tags=["responses"])

app.include_router(get_llm_router(), prefix="/api/v1/llm", tags=["llm"])

app.include_router(get_sync_router(), prefix="/api/v1/sync", tags=["sync"])

app.include_router(
    get_users_router(),
    prefix="/api/v1/users",
    tags=["users"],
)

app.include_router(
    get_user_id_by_email_router(),
    prefix="/api/v1/users",
    tags=["users"],
)

app.include_router(
    get_checks_router(),
    prefix="/api/v1/checks",
    tags=["checks"],
)

app.include_router(
    get_health_router(),
    prefix="/health",
    tags=["health"],
)

app.include_router(get_agents_router(), prefix="/api/v1/agents")

# Activity / observability
app.include_router(
    get_activity_router(),
    prefix="/api/v1/activity",
    tags=["activity"],
)

# Sessions lifecycle + dashboard aggregates
app.include_router(
    get_sessions_router(),
    prefix="/api/v1/sessions",
    tags=["sessions"],
)

app.include_router(get_remember_router(), prefix="/api/v1/remember", tags=["remember"])
app.include_router(get_recall_router(), prefix="/api/v1/recall", tags=["recall"])
app.include_router(get_improve_router(), prefix="/api/v1/improve", tags=["improve"])
app.include_router(get_forget_router(), prefix="/api/v1/forget", tags=["forget"])

app.include_router(get_slack_router(), prefix="/api/v1/slack", tags=["slack"])
app.include_router(get_slack_channels_router(), prefix="/api/v1/slack", tags=["slack"])
app.include_router(get_integrations_router(), prefix="/api/v1/integrations", tags=["integrations"])


@app.get("/")
async def root():
    """
    Root endpoint that returns a welcome message.
    """
    return {"message": "Hello, World, I am alive!"}


def start_api_server(host: str = "0.0.0.0", port: int = 8000):
    """
    Start the API server using uvicorn.
    Parameters:
    host (str): The host for the server.
    port (int): The port for the server.
    """
    import socket

    try:
        logger.info("Starting server at %s:%s", host, port)

        # Bind before serving so the port is held during startup (including the
        # lifespan migration): uvicorn runs the lifespan before it accepts on this
        # socket, so while migrating, a second server on the same host:port fails
        # fast with EADDRINUSE and no endpoint is served yet (requests queue).
        # reuse_port=False keeps that guard — SO_REUSEPORT would let a second
        # process share the port.
        sock = socket.create_server((host, port), reuse_port=False)

        config = uvicorn.Config(app, host=host, port=port)
        uvicorn.Server(config).run(sockets=[sock])
    except Exception:
        logger.exception("Failed to start server")
        # Here you could add any cleanup code or error recovery code.
        raise


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Cognee API server")
    parser.add_argument(
        "--agent-mode",
        action="store_true",
        default=None,
        help="Enable agent mode (overrides COGNEE_AGENT_MODE env var)",
    )
    args = parser.parse_args()

    from cognee.modules.agents.agent_mode import is_agent_mode_enabled, set_agent_mode

    if args.agent_mode:
        set_agent_mode(True)

    default_port = 8011 if is_agent_mode_enabled() else 8000

    logger = setup_logging()

    start_api_server(
        host=os.getenv("HTTP_API_HOST", "0.0.0.0"),
        port=int(os.getenv("HTTP_API_PORT", default_port)),
    )

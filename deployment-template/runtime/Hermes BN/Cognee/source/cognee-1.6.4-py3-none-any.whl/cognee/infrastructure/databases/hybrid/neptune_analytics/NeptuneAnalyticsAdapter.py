"""Neptune Analytics Hybrid Adapter combining Vector and Graph functionality"""

import asyncio
import json
from collections import Counter
from typing import Any
from uuid import UUID

from cognee.infrastructure.databases.exceptions import (
    MissingQueryParameterError,
    MutuallyExclusiveQueryParametersError,
)
from cognee.infrastructure.databases.graph.neptune_driver.adapter import NeptuneGraphDB
from cognee.infrastructure.databases.vector.embeddings.EmbeddingEngine import EmbeddingEngine
from cognee.infrastructure.databases.vector.models.PayloadSchema import PayloadSchema
from cognee.infrastructure.databases.vector.models.ScoredResult import ScoredResult
from cognee.infrastructure.databases.vector.vector_db_interface import VectorDBInterface
from cognee.infrastructure.engine import DataPoint
from cognee.modules.graph.models.EdgeType import EdgeType
from cognee.modules.graph.utils.prepare_edges_for_storage import get_edge_retrieval_text
from cognee.modules.storage.utils import JSONEncoder
from cognee.shared.logging_utils import get_logger

logger = get_logger("NeptuneAnalyticsAdapter")


class IndexSchema(DataPoint):
    """
    Represents a schema for an index data point containing an ID and text.

    Attributes:
    - id: A string representing the unique identifier for the data point.
    - text: A string representing the content of the data point.
    - belongs_to_set: A list of node names this data point belongs to, used for filtering.
    - metadata: A dictionary with default index fields for the schema, currently configured
    to include 'text'.
    """

    id: str
    text: str
    # Optional reference scalars carried for the search "Evidence" feature.
    # They stay None for non-chunk data points, so this schema remains
    # compatible with every indexed DataPoint type.
    document_id: str | None = None
    document_name: str | None = None
    chunk_index: int | None = None
    source_chunk_id: str | None = None
    importance_weight: float | None = 0.5
    # Document external_metadata as JSON text, copied onto chunks at ingest so
    # hybrid retrieval can surface allowlisted keys straight from the payload.
    external_metadata: str | None = None
    belongs_to_set: list[str] = []
    metadata: dict = {"index_fields": ["text"]}


NEPTUNE_ANALYTICS_ENDPOINT_URL = "neptune-graph://"


class NeptuneAnalyticsAdapter(NeptuneGraphDB, VectorDBInterface):
    """
    Hybrid adapter that combines Neptune Analytics Vector and Graph functionality.

    This adapter extends NeptuneGraphDB and implements VectorDBInterface to provide
    a unified interface for working with Neptune Analytics as both a vector store
    and a graph database.
    """

    _VECTOR_NODE_LABEL = "COGNEE_NODE"
    _COLLECTION_PREFIX = "VECTOR_COLLECTION"
    _TOPK_LOWER_BOUND = 0
    _TOPK_UPPER_BOUND = 10

    def __init__(
        self,
        graph_id: str,
        embedding_engine: EmbeddingEngine | None = None,
        region: str | None = None,
        aws_access_key_id: str | None = None,
        aws_secret_access_key: str | None = None,
        aws_session_token: str | None = None,
    ):
        """
        Initialize the Neptune Analytics hybrid adapter.

        Parameters:
        -----------
            - graph_id (str): The Neptune Analytics graph identifier
            - embedding_engine(Optional[EmbeddingEngine]): The embedding engine instance to translate text to vector.
            - region (Optional[str]): AWS region where the graph is located (default: us-east-1)
            - aws_access_key_id (Optional[str]): AWS access key ID
            - aws_secret_access_key (Optional[str]): AWS secret access key
            - aws_session_token (Optional[str]): AWS session token for temporary credentials
        """
        # Initialize the graph database functionality
        super().__init__(
            graph_id=graph_id,
            region=region,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            aws_session_token=aws_session_token,
        )

        # Add vector-specific attributes
        self.embedding_engine = embedding_engine
        logger.info('Initialized Neptune Analytics hybrid adapter in region: "%s"', self.region)

    # VectorDBInterface methods implementation

    async def get_connection(self):
        """
        This method is part of the default implementation but not defined in the interface.
        No operation is performed and None will be returned here,
        because the concept of connection is not applicable in this context.
        """
        return

    async def embed_data(self, data: list[str]) -> list[list[float]]:
        """
        Embeds the provided textual data into vector representation.

        Uses the embedding engine to convert the list of strings into a list of float vectors.

        Parameters:
        -----------
            - data (list[str]): A list of strings representing the data to be embedded.

        Returns:
        --------
            - list[list[float]]: A list of embedded vectors corresponding to the input data.
        """
        self._validate_embedding_engine()
        return await self.embedding_engine.embed_text(data)

    async def has_collection(self, collection_name: str) -> bool:
        """
        Neptune Analytics stores vector on a node level,
        so create_collection() implements interface for compliance but performs no operations when called.

        Parameters:
        -----------
            - collection_name (str): The name of the collection to check for existence.
        Returns:
        --------
            - bool: Always return True.
        """
        return True

    async def create_collection(
        self,
        collection_name: str,
        payload_schema: PayloadSchema | None = None,
    ):
        """
        Neptune Analytics stores vector on a node level, so create_collection() implements interface for compliance but performs no operations when called.
        As the result, create_collection() will be no-op.

        Parameters:
        -----------
            - collection_name (str): The name of the new collection to create.
            - payload_schema (Optional[PayloadSchema]): An optional schema for the payloads
              within this collection. (default None)
        """

    async def get_collection(self, collection_name: str):
        """
        This method is part of the default implementation but not defined in the interface.
        No operation is performed here because the concept of collection is not applicable in NeptuneAnalytics vector store.
        """
        return

    async def create_data_points(self, collection_name: str, data_points: list[DataPoint]):
        """
        Insert new data points into the specified collection, by first inserting the node itself on the graph,
        then execute neptune.algo.vectors.upsert() to insert the corresponded embedding.

        Parameters:
        -----------
            - collection_name (str): The name of the collection where data points will be added.
            - data_points (List[DataPoint]): A list of data points to be added to the
              collection.
        """
        self._validate_embedding_engine()

        # Fetch embeddings
        texts = [DataPoint.get_embeddable_data(t) for t in data_points]
        data_vectors = await self.embedding_engine.embed_text(texts)

        for index, data_point in enumerate(data_points):
            node_id = data_point.id
            # Fetch embedding from list instead
            data_vector = data_vectors[index]

            # Fetch properties
            properties = self._serialize_properties(data_point.model_dump())
            properties[self._COLLECTION_PREFIX] = collection_name
            params = {
                "node_id": str(node_id),
                "properties": properties,
                "embedding": data_vector,
                "collection_name": collection_name,
            }

            # Compose the query and send
            query_string = (
                f"MERGE (n "
                f":{self._VECTOR_NODE_LABEL} "
                f" {{`~id`: $node_id}}) "
                f"ON CREATE SET n = $properties, n.updated_at = timestamp() "
                f"ON MATCH SET n += $properties, n.updated_at = timestamp() "
                f"WITH n, $embedding AS embedding "
                f"CALL neptune.algo.vectors.upsert(n, embedding) "
                f"YIELD success "
                f"RETURN success "
            )

            try:
                self._client.query(query_string, params)
            except Exception as e:
                logger.debug(
                    "Ignoring exception in NeptuneAnalyticsAdapter.create_data_points",
                    exc_info=True,
                )
                self._na_exception_handler(e, query_string)

    async def retrieve(self, collection_name: str, data_point_ids: list[str]):
        """
        Retrieve data points from a collection using their IDs.

        Parameters:
        -----------
            - collection_name (str): The name of the collection from which to retrieve data
              points.
            - data_point_ids (list[str]): A list of IDs of the data points to retrieve.
        """
        # Do the fetch for each node
        params = {"node_ids": data_point_ids, "collection_name": collection_name}
        query_string = (
            f"MATCH( n :{self._VECTOR_NODE_LABEL}) "
            f"WHERE id(n) in $node_ids AND "
            f"n.{self._COLLECTION_PREFIX} = $collection_name "
            f"RETURN n as payload "
        )

        try:
            result = self._client.query(query_string, params)
            return [
                ScoredResult(
                    id=(item.get("payload") or {}).get("~id"),
                    payload=(item.get("payload") or {}).get("~properties"),
                    score=0,
                )
                for item in result
            ]
        except Exception as e:
            logger.debug("Ignoring exception in NeptuneAnalyticsAdapter.retrieve", exc_info=True)
            self._na_exception_handler(e, query_string)

    async def search(
        self,
        collection_name: str,
        query_text: str | None = None,
        query_vector: list[float] | None = None,
        limit: int | None = None,
        with_vector: bool = False,
        include_payload: bool = False,
        node_name: list[str] | None = None,
        node_name_filter_operator: str = "OR",
    ):
        """
        Perform a search in the specified collection using either a text query or a vector
        query.

        Parameters:
        -----------
            - collection_name (str): The name of the collection in which to perform the search.
            - query_text (Optional[str]): An optional text query to search for in the
              collection.
            - query_vector (Optional[List[float]]): An optional vector representation for
              searching the collection.
            - limit (int): The maximum number of results to return from the search.
            - with_vector (bool): Whether to return the vector representations with search
              results, this is not supported for Neptune Analytics backend at the moment.
            - include_payload (bool): When True, fetch full node properties and populate
              ``ScoredResult.payload``. When False (default), only node IDs are returned and
              ``payload`` is set to None, reducing data transfer.
            - node_name (Optional[List[str]]): Optional list of set names to filter results
              by ``belongs_to_set`` membership.
            - node_name_filter_operator (str): ``"OR"`` (default) matches nodes belonging to
              any of the ``node_name`` values; ``"AND"`` requires membership in all of them.

        Returns:
        --------
            A list of scored results that match the query.
        """
        self._validate_embedding_engine()

        if with_vector:
            logger.warning(
                "with_vector=True will include embedding vectors in the result. "
                "This may trigger a resource-intensive query and increase response time. "
                "Use this option only when vector data is required."
            )

        # In the case of excessive limit, or None / zero / negative value, limit will be set to 10.
        if not limit or limit <= self._TOPK_LOWER_BOUND or limit > self._TOPK_UPPER_BOUND:
            logger.warning(
                "Provided limit (%s) is invalid (None, zero, negative, or exceeds maximum). "
                "Defaulting to limit=10.",
                limit,
            )
            limit = self._TOPK_UPPER_BOUND

        if query_vector and query_text:
            raise MutuallyExclusiveQueryParametersError()
        elif query_text is None and query_vector is None:
            raise MissingQueryParameterError()
        elif query_vector:
            embedding = query_vector
        else:
            data_vectors = await self.embedding_engine.embed_text([query_text])
            embedding = data_vectors[0]

        # Compose the parameters map
        params = {"embedding": embedding, "param_topk": limit}
        # Compose the query
        query_string = f"""
        CALL neptune.algo.vectors.topKByEmbeddingWithFiltering({{
                topK: {limit},
                embedding: {embedding},
                nodeFilter: {{ equals: {{property: '{self._COLLECTION_PREFIX}', value: '{collection_name}'}} }}
              }}
            )
        YIELD node, score
        """

        # Filter by belongs_to_set if node_name is provided
        if node_name:
            escaped_names = [name.replace("'", "\\'") for name in node_name]
            name_list = ", ".join(f"'{name}'" for name in escaped_names)

            if node_name_filter_operator == "OR":
                query_string += f"""
                WITH node, score
                WHERE any(name IN node.belongs_to_set WHERE name IN [{name_list}])
                """
            else:
                query_string += f"""
                WITH node, score
                WHERE all(name IN node.belongs_to_set WHERE name IN [{name_list}])
                """

        if with_vector:
            query_string += """
        WITH node, score
        MATCH (n)
        WHERE id(n) = id(node)
        CALL neptune.algo.vectors.get(n)
        YIELD embedding
        """

        payload_part = "node as payload" if include_payload else "id(node) as node_id"
        embedding_part = ", embedding" if with_vector else ""
        query_string += f"RETURN {payload_part}, score{embedding_part}"

        try:
            query_response = self._client.query(query_string, params)
            results = []
            for item in query_response:
                payload_obj = item.get("payload") or {}
                results.append(
                    ScoredResult(
                        id=payload_obj.get("~id") if include_payload else item.get("node_id"),
                        payload=payload_obj.get("~properties") if include_payload else None,
                        score=item.get("score", 0),
                    )
                )
            return results
        except Exception as e:
            logger.debug("Ignoring exception in NeptuneAnalyticsAdapter.search", exc_info=True)
            self._na_exception_handler(e, query_string)

    async def batch_search(
        self,
        collection_name: str,
        query_texts: list[str],
        limit: int,
        with_vectors: bool = False,
        include_payload: bool = False,
        node_name: list[str] | None = None,
        node_name_filter_operator: str = "OR",
    ):
        """
        Perform a batch search using multiple text queries against a collection.

        Parameters:
        -----------
            - collection_name (str): The name of the collection to conduct the batch search in.
            - query_texts (List[str]): A list of text queries to use for the search.
            - limit (int): The maximum number of results to return for each query.
            - with_vectors (bool): Whether to include vector representations with search
              results. (default False)

        Returns:
        --------
            A list of search result sets, one for each query input.
        """
        self._validate_embedding_engine()

        # Convert text to embedding array in batch
        data_vectors = await self.embedding_engine.embed_text(query_texts)
        return await asyncio.gather(
            *[
                self.search(
                    collection_name,
                    None,
                    vector,
                    limit,
                    with_vectors,
                    include_payload=include_payload,
                    node_name=node_name,
                    node_name_filter_operator=node_name_filter_operator,
                )
                for vector in data_vectors
            ]
        )

    async def delete_data_points(self, collection_name: str, data_point_ids: list[str]):
        """
        Delete specified data points from a collection, by executing an OpenCypher query,
        with matching [vector_label, collection_label, node_id] combination.

        Parameters:
        -----------
            - collection_name (str): The name of the collection from which to delete data
              points.
            - data_point_ids (list[str]): A list of IDs of the data points to delete.
        """
        params = {"node_ids": data_point_ids, "collection_name": collection_name}
        query_string = (
            f"MATCH (n :{self._VECTOR_NODE_LABEL}) "
            f"WHERE id(n) IN $node_ids "
            f"AND n.{self._COLLECTION_PREFIX} = $collection_name "
            f"DETACH DELETE n"
        )
        try:
            self._client.query(query_string, params)
        except Exception as e:
            logger.debug(
                "Ignoring exception in NeptuneAnalyticsAdapter.delete_data_points", exc_info=True
            )
            self._na_exception_handler(e, query_string)

    async def create_vector_index(self, index_name: str, index_property_name: str):
        """
        Neptune Analytics stores vectors at the node level,
        so create_vector_index() implements the interface for compliance but performs no operation when called.
        As a result, create_vector_index() invokes create_collection(), which is also a no-op.
        This ensures the logic flow remains consistent, even if the concept of collections is introduced in a future release.
        """
        await self.create_collection(f"{index_name}_{index_property_name}")

    async def index_data_points(
        self, index_name: str, index_property_name: str, data_points: list[DataPoint]
    ):
        """
        Indexes a list of data points into Neptune Analytics by creating them as nodes.

        This method constructs a unique collection name by combining the `index_name` and
        `index_property_name`, then delegates to `create_data_points()` to store the data.

        Args:
            index_name (str): The base name of the index.
            index_property_name (str): The property name to append to the index name for uniqueness.
            data_points (list[DataPoint]): A list of `DataPoint` instances to be indexed.

        Returns:
            None
        """
        await self.create_data_points(
            f"{index_name}_{index_property_name}",
            [
                IndexSchema(
                    id=str(data_point.id),
                    text=getattr(data_point, data_point.metadata["index_fields"][0]),
                    # Reference scalars for search "Evidence". Pulled via getattr
                    # so non-chunk data points (which lack these fields) simply
                    # fall back to None instead of raising.
                    document_id=getattr(data_point, "document_id", None),
                    document_name=getattr(data_point, "document_name", None),
                    chunk_index=getattr(data_point, "chunk_index", None),
                    source_chunk_id=getattr(data_point, "source_chunk_id", None),
                    importance_weight=getattr(data_point, "importance_weight", None),
                    external_metadata=getattr(data_point, "external_metadata", None),
                )
                for data_point in data_points
            ],
        )

    async def prune(self):
        """
        Remove obsolete or unnecessary data from the database.
        """
        # Run actual truncate
        self._client.query(f"MATCH (n :{self._VECTOR_NODE_LABEL}) DETACH DELETE n")

    async def is_empty(self) -> bool:
        query = """
        MATCH (n)
        RETURN true
        LIMIT 1;
        """
        query_result = self._client.query(query)
        return len(query_result) == 0

    def _na_exception_handler(self, ex, query_string: str):
        """
        Generic exception handler for NA langchain.
        """
        logger.error("Neptune Analytics query failed: %s | Query: [%s]", ex, query_string)
        raise ex

    def _validate_embedding_engine(self):
        """
        Validates if the embedding_engine is defined
        :raises: ValueError if this object does not have a valid embedding_engine
        """
        if self.embedding_engine is None:
            raise ValueError(
                "Neptune Analytics requires an embedder defined to make vector operations"
            )

    async def add_nodes_with_vectors(self, data_points: list[DataPoint]) -> None:
        """Add nodes to the graph and index their embeddable fields as vector data points.

        This is the hybrid write path for Neptune Analytics: graph nodes are inserted
        via ``add_nodes`` and vector embeddings are stored as COGNEE_NODE entries
        grouped by ``(TypeName, field_name)`` collection.

        Parameters:
        -----------
            - data_points (List[DataPoint]): Nodes to insert. Each node's
              ``metadata["index_fields"]`` controls which fields are embedded.
        """
        if not data_points:
            return

        await self.add_nodes(data_points)

        # Group by (type_name, field_name) to build one collection per field.
        groups: dict[tuple[str, str], list[DataPoint]] = {}
        for dp in data_points:
            if not hasattr(dp, "metadata") or not dp.metadata:
                continue
            type_name = type(dp).__name__
            for field_name in dp.metadata.get("index_fields", []):
                if getattr(dp, field_name, None) is None:
                    continue
                key = (type_name, field_name)
                groups.setdefault(key, []).append(dp)

        for (type_name, field_name), points in groups.items():
            await self.create_vector_index(type_name, field_name)
            index_schemas = [
                IndexSchema(
                    id=str(dp.id),
                    text=getattr(dp, field_name),
                    document_id=getattr(dp, "document_id", None),
                    document_name=getattr(dp, "document_name", None),
                    chunk_index=getattr(dp, "chunk_index", None),
                    source_chunk_id=getattr(dp, "source_chunk_id", None),
                    importance_weight=getattr(dp, "importance_weight", None),
                    belongs_to_set=dp.belongs_to_set or [],
                )
                for dp in points
            ]
            await self.create_data_points(f"{type_name}_{field_name}", index_schemas)

    async def add_edges_with_vectors(
        self, edges: list[tuple[str, str, str, dict[str, Any]]]
    ) -> None:
        """Add edges to the graph and index unique relationship types as vector data points.

        Graph edges are inserted via ``add_edges``. Each distinct relationship type
        (or ``edge_text`` when present in edge properties) is embedded and stored as a
        COGNEE_NODE in the ``EdgeType_relationship_name`` collection, matching the
        behaviour of the non-hybrid ``index_graph_edges`` task.

        Parameters:
        -----------
            - edges (List[Tuple]): Edges in ``(source_id, target_id, rel_name, props)``
              format, as produced by ``get_graph_from_model``.
        """
        if not edges:
            return

        await self.add_edges(edges)

        # Collect unique edge texts for embedding.
        edge_texts = []
        for edge in edges:
            props = edge[3] if len(edge) > 3 and edge[3] else {}
            edge_text = get_edge_retrieval_text(props.get("edge_text"), edge[2])
            if edge_text:
                edge_texts.append(edge_text)

        edge_type_counts = Counter(edge_texts)
        if not edge_type_counts:
            return

        await self.create_vector_index("EdgeType", "relationship_name")
        index_schemas = [
            IndexSchema(
                id=str(EdgeType.id_for(text)),
                text=text,
                belongs_to_set=[],
            )
            for text in edge_type_counts
        ]
        await self.create_data_points("EdgeType_relationship_name", index_schemas)

    async def run_migrations(self):
        """Run Neptune Analytics adapter migrations (currently no-op)."""
        return

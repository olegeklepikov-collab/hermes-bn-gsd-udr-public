"""Bundled source namespace."""

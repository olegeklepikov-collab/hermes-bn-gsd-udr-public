roxygen_setup <- function(
  path = ".",
  cur_version = NULL,
  frame = caller_env()
) {
  if (!file.exists(file.path(path, "DESCRIPTION"))) {
    cli::cli_abort(
      "{.arg package.dir} ({.path {path}}) does not contain a DESCRIPTION file.",
      call = frame
    )
  }

  is_first <- first_time(path)
  if (is_first) {
    cli::cli_inform(
      "First time using {.pkg roxygen2}. Upgrading automatically..."
    )
  }

  update_roxygen_version(path, cur_version = cur_version)

  encoding <- desc::desc_get("Encoding", path)[[1]]
  if (!identical(encoding, "UTF-8")) {
    cli::cli_inform(c(
      x = "{.pkg roxygen2} requires {.val Encoding: UTF-8}",
      i = "Current encoding is {.val {encoding}}"
    ))
  }

  man_path <- file.path(path, "man")
  dir.create(man_path, recursive = TRUE, showWarnings = FALSE)

  withr::local_envvar(
    ROXYGEN_PKG = desc::desc_get("Package", path),
    .local_envir = frame
  )

  is_first
}

peek_roxygen_pkg <- function() {
  pkg <- Sys.getenv("ROXYGEN_PKG")

  if (nzchar(pkg)) {
    pkg
  } else {
    NULL
  }
}

update_roxygen_version <- function(path, cur_version = NULL) {
  cur <- cur_version %||% as.character(utils::packageVersion("roxygen2"))
  prev <- roxygen_version(path)

  if (
    !is.na(cur) && !is.na(prev) && package_version(cur) < package_version(prev)
  ) {
    cli::cli_inform(c(
      x = "Installed {.pkg roxygen2} is older than the version used with this package",
      i = "You have {.val {cur}} but you need {.val {prev}}"
    ))
    return(invisible())
  }

  if (
    !identical(cur, prev) && !is.na(prev) && numeric_version(prev) <= "6.1.99"
  ) {
    cli::cli_rule()
    cli::cli_inform(c(
      "Changes in {.pkg roxygen2} 7.0.0:",
      "* `%` is now escaped automatically in Markdown mode.",
      "Please carefully check .Rd files for changes"
    ))
    cli::cli_rule()
  }

  # Check the fields individually, rather than relying on `prev`, since an
  # older roxygen2 might have re-added `RoxygenNote` after migration (#1876)
  if (!identical(trimws(desc_version(path)), cur)) {
    cli::cli_inform(c(
      i = "Setting {.field Config/roxygen2/version} to {.val {cur}}"
    ))
    desc::desc_set("Config/roxygen2/version" = cur, file = path)
  }
  if (desc::desc_has_fields("RoxygenNote", file = path)) {
    desc::desc_del("RoxygenNote", file = path)
  }
}

first_time <- function(path) {
  if (!is.na(roxygen_version(path))) {
    return(FALSE)
  }

  generated <- dir(file.path(path, "man"), full.names = TRUE)
  generated <- generated[!file.info(generated)$isdir]

  namespace <- file.path(path, "NAMESPACE")
  if (file.exists(namespace)) {
    generated <- c(generated, namespace)
  }

  roxy <- map_lgl(generated, made_by_roxygen)
  all(!roxy)
}

roxygen_version <- function(path = ".") {
  version <- desc_version(path)
  if (is.na(version)) {
    version <- desc::desc_get("RoxygenNote", file = path)[[1]]
  }
  trimws(version)
}

desc_version <- function(path = ".") {
  desc::desc_get("Config/roxygen2/version", file = path)[[1]]
}

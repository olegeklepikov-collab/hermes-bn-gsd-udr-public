#' Queue only the latest expensive range-style request for a version
#' @noRd
enqueue_latest_reply <- function(self, uri, method, item) {
    queue <- self$pending_replies$get(uri)[[method]]
    retained <- list()
    while (queue$size()) {
        previous <- queue$pop()
        if (isTRUE(previous$version == item$version)) {
            self$deliver(ResponseErrorMessage$new(
                previous$id,
                "RequestCancelled",
                "Request superseded by a newer request"
            ))
        } else {
            retained[[length(retained) + 1L]] <- previous
        }
    }
    for (previous in retained) queue$push(previous)
    queue$push(item)
}

#' `textDocument/completion` request handler
#'
#' Handler to the `textDocument/completion` [Request].
#' @noRd
text_document_completion  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    point <- document$from_lsp_position(params$position)
    self$deliver(completion_reply(id, uri, workspace, document, point,
        self$ClientCapabilities$textDocument$completion))
}

#' `completionItem/resolve` request handler
#'
#' Handler to the `completionItem/resolve` [Request].
#' @noRd
completion_item_resolve  <- function(self, id, params) {
    # Resolve uri from completion item if possible
    uri <- params$data$uri
    if (is.null(uri)) uri <- params$data$textDocument$uri
    workspace <- self$get_workspace(uri)

    self$deliver(completion_item_resolve_reply(
        id, workspace, params,
        self$ClientCapabilities$textDocument$completion))
}
#' `textDocument/hover` request handler
#'
#' Handler to the `textDocument/hover` [Request].
#'
#' @noRd
text_document_hover  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    point <- document$from_lsp_position(params$position)
    self$deliver(hover_reply(id, uri, workspace, document, point))
}

#' `textDocument/signatureHelp` request handler
#'
#' Handler to the `textDocument/signatureHelp` [Request].
#'
#' @noRd
text_document_signature_help  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    point <- document$from_lsp_position(params$position)
    self$deliver(signature_reply(id, uri, workspace, document, point))
}

#' `textDocument/definition` request handler
#'
#' Handler to the `textDocument/definition` [Request].
#' @noRd
text_document_definition  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    point <- document$from_lsp_position(params$position)
    rootPath <- get_root_path_for_uri(uri, self$rootPath)
    self$deliver(definition_reply(id, uri, workspace, document, point, rootPath))
}

#' `textDocument/typeDefinition` request handler
#'
#' Handler to the `textDocument/typeDefinition` [Request].
#'
#' @noRd
text_document_type_definition  <- function(self, id, params) {

}

#' `textDocument/implementation` request handler
#'
#' Handler to the `textDocument/implementation` [Request].
#' @noRd
text_document_implementation  <- function(self, id, params) {

}

#' `textDocument/references` request handler
#'
#' Handler to the `textDocument/references` [Request].
#' @noRd
text_document_references  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    point <- document$from_lsp_position(params$position)
    self$deliver(references_reply(id, uri, workspace, document, point))
}

#' `textDocument/documentHighlight` request handler
#'
#' Handler to the `textDocument/documentHighlight` [Request].
#' @noRd
text_document_document_highlight  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    point <- document$from_lsp_position(params$position)
    self$deliver(document_highlight_reply(id, uri, workspace, document, point))
}

#' `textDocument/documentSymbol` request handler
#'
#' Handler to the `textDocument/documentSymbol` [Request].
#' @noRd
text_document_document_symbol  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    reply <- document_symbol_reply(id, uri, workspace, document,
        self$ClientCapabilities$textDocument$documentSymbol)
    if (is.null(reply)) {
        queue <- self$pending_replies$get(uri)[["textDocument/documentSymbol"]]
        queue$push(list(
            id = id,
            version = document$version,
            params = params
        ))
    } else {
        self$deliver(reply)
    }
}

#' `textDocument/codeAction` request handler
#'
#' Handler to the `textDocument/codeAction` [Request].
#' @noRd
text_document_code_action  <- function(self, id, params) {
    logger$info("text_document_code_action: ", params)
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    range <- list(
        start = document$from_lsp_position(params$range$start),
        end = document$from_lsp_position(params$range$end)
    )
    context <- params$context
    self$deliver(document_code_action_reply(
        id, uri, workspace, document, range, context,
        self$ClientCapabilities))
}

#' `textDocument/codeLens` request handler
#'
#' Handler to the `textDocument/codeLens` [Request].
#' @noRd
text_document_code_lens  <- function(self, id, params) {
    uri <- uri_escape_unicode(params$textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))

    reply <- code_lens_reply(
        id, uri, workspace, document, self$ClientCapabilities)
    if (is.null(reply)) {
        queue <- self$pending_replies$get(uri)[["textDocument/codeLens"]]
        queue$push(list(id = id, version = document$version, params = params))
    } else {
        self$deliver(reply)
    }
}

#' `codeLens/resolve` request handler
#'
#' Handler to the `codeLens/resolve` [Request].
#' @noRd
code_lens_resolve  <- function(self, id, params) {
    uri <- params$data$uri
    workspace <- self$get_workspace(uri)
    self$deliver(code_lens_resolve_reply(id, workspace, params))
}


#' `textDocument/documentLink` request handler
#'
#' Handler to the `textDocument/documentLink` [Request].
#' @noRd
text_document_document_link  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    rootPath <- get_root_path_for_uri(uri, self$rootPath)
    reply <- document_link_reply(id, uri, workspace, document, rootPath)
    if (is.null(reply)) {
        queue <- self$pending_replies$get(uri)[["textDocument/documentLink"]]
        queue$push(list(
            id = id,
            version = document$version,
            params = params
        ))
    } else {
        self$deliver(reply)
    }
}

#' `documentLink/resolve` request handler
#'
#' Handler to the `documentLink/resolve` [Request].
#' @noRd
document_link_resolve  <- function(self, id, params) {
    uri <- params$data$uri
    if (is.null(uri)) uri <- params$data$textDocument$uri
    workspace <- self$get_workspace(uri)

    reply <- document_link_resolve_reply(id, workspace, params)
    self$deliver(reply)

    if (!is.null(reply$error)) {
        self$deliver(
            Notification$new(
                method = "window/showMessage",
                params = list(
                    type = MessageType$Error,
                    message = reply$error$message
                )
            )
        )
    }
}

#' `textDocument/documentColor` request handler
#'
#' Handler to the `textDocument/documentColor` [Request].
#' @noRd
text_document_document_color  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    reply <- document_color_reply(id, uri, workspace, document)
    if (is.null(reply)) {
        queue <- self$pending_replies$get(uri)[["textDocument/documentColor"]]
        queue$push(list(
            id = id,
            version = document$version,
            params = params
        ))
    } else {
        self$deliver(reply)
    }
}

#' `textDocument/colorPresentation` request handler
#'
#' Handler to the `textDocument/colorPresentation` [Request].
#' @noRd
text_document_color_presentation  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    color <- params$color
    self$deliver(color_presentation_reply(id, uri, workspace, document, color))
}

#' `textDocument/formatting` request handler
#'
#' Handler to the `textDocument/formatting` [Request].
#' @noRd
text_document_formatting  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    options <- params$options
    enqueue_formatting(self, id, uri, document, options)
}

#' `textDocument/rangeFormatting` request handler
#'
#' Handler to the `textDocument/rangeFormatting` [Request].
#' @noRd
text_document_range_formatting  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    range <- list(
        start = document$from_lsp_position(params$range$start),
        end = document$from_lsp_position(params$range$end)
    )
    options <- params$options
    enqueue_formatting(self, id, uri, document, options, range = range)
}

#' `textDocument/rangesFormatting` request handler (LSP 3.18)
#' @noRd
text_document_ranges_formatting <- function(self, id, params) {
    uri <- uri_escape_unicode(params$textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))

    ranges <- lapply(params$ranges, function(item) {
        list(
            start = document$from_lsp_position(item$start),
            end = document$from_lsp_position(item$end)
        )
    })
    enqueue_formatting(self, id, uri, document, params$options, ranges = ranges)
}


#' `textDocument/onTypeFormatting` request handler
#'
#' Handler to the `textDocument/onTypeFormatting` [Request].
#' @noRd
text_document_on_type_formatting  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    point <- document$from_lsp_position(params$position)
    ch <- params$ch
    options <- params$options
    self$deliver(on_type_formatting_reply(id, uri, document, point, ch, options))
}


#' `textDocument/rename` request handler
#'
#' Handler to the `textDocument/rename` [Request].
#' @noRd
text_document_rename <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    point <- document$from_lsp_position(params$position)
    newName <- params$newName
    self$deliver(rename_reply(id, uri, workspace, document, point, newName))
}

#' `textDocument/prepareRename` request handler
#'
#' Handler to the `textDocument/prepareRename` [Request].
#' @noRd
text_document_prepare_rename  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    point <- document$from_lsp_position(params$position)
    self$deliver(prepare_rename_reply(id, uri, workspace, document, point))
}

#' `textDocument/foldingRange` request handler
#'
#' Handler to the `textDocument/foldingRange` [Request].
#' @noRd
text_document_folding_range  <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    reply <- document_folding_range_reply(id, uri, workspace, document)
    if (is.null(reply)) {
        queue <- self$pending_replies$get(uri)[["textDocument/foldingRange"]]
        queue$push(list(
            id = id,
            version = document$version,
            params = params
        ))
    } else {
        self$deliver(reply)
    }
}

#' `textDocument/selectionRange` request handler
#'
#' Handler to the `textDocument/selectionRange` [Request].
#' @noRd
text_document_selection_range <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    points <- lapply(params$positions, document$from_lsp_position)
    self$deliver(selection_range_reply(id, uri, workspace, document, points))
}

#' `textDocument/prepareCallHierarchy` request handler
#'
#' Handler to the `textDocument/prepareCallHierarchy` [Request].
#' @noRd
text_document_prepare_call_hierarchy <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    point <- document$from_lsp_position(params$position)
    self$deliver(prepare_call_hierarchy_reply(id, uri, workspace, document, point))
}

#' `callHierarchy/incomingCalls` request handler
#'
#' Handler to the `callHierarchy/incomingCalls` [Request].
#' @noRd
call_hierarchy_incoming_calls <- function(self, id, params) {
    uri <- params$item$uri
    workspace <- self$get_workspace(uri)
    self$deliver(
        call_hierarchy_incoming_calls_reply(id, workspace, params$item)
    )
}

#' `callHierarchy/outgoingCalls` request handler
#'
#' Handler to the `callHierarchy/outgoingCalls` [Request].
#' @noRd
call_hierarchy_outgoing_calls <- function(self, id, params) {
    uri <- params$item$uri
    workspace <- self$get_workspace(uri)
    self$deliver(
        call_hierarchy_outgoing_calls_reply(id, workspace, params$item)
    )
}

#' `textDocument/prepareTypeHierarchy` request handler
#'
#' Handler to the `textDocument/prepareTypeHierarchy` [Request].
#' @noRd
text_document_prepare_type_hierarchy <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    point <- document$from_lsp_position(params$position)
    self$deliver(prepare_type_hierarchy_reply(id, uri, workspace, document, point))
}

#' `typeHierarchy/supertypes` request handler
#'
#' Handler to the `typeHierarchy/supertypes` [Request].
#' @noRd
type_hierarchy_supertypes <- function(self, id, params) {
    uri <- params$item$uri
    workspace <- self$get_workspace(uri)
    self$deliver(
        type_hierarchy_supertypes_reply(id, workspace, params$item)
    )
}

#' `typeHierarchy/subtypes` request handler
#'
#' Handler to the `typeHierarchy/subtypes` [Request].
#' @noRd
type_hierarchy_subtypes <- function(self, id, params) {
    uri <- params$item$uri
    workspace <- self$get_workspace(uri)
    self$deliver(
        type_hierarchy_subtypes_reply(id, workspace, params$item)
    )
}

#' `textDocument/linkedEditingRange` request handler
#'
#' Handler to the `textDocument/linkedEditingRange` [Request].
#' @noRd
text_document_linked_editing_range <- function(self, id, params) {
    uri <- uri_escape_unicode(params$textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))

    reply <- linked_editing_range_reply(
        id, uri, workspace, document, params$position)
    if (is.null(reply)) {
        queue <- self$pending_replies$get(uri)[["textDocument/linkedEditingRange"]]
        queue$push(list(id = id, version = document$version, params = params))
    } else {
        self$deliver(reply)
    }
}

#' `textDocument/inlineValue` request handler
#' @noRd
text_document_inline_value <- function(self, id, params) {
    uri <- uri_escape_unicode(params$textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))

    reply <- inline_value_reply(id, uri, workspace, document, params$range)
    if (is.null(reply)) {
        enqueue_latest_reply(self, uri, "textDocument/inlineValue", list(
            id = id, version = document$version, params = params))
    } else {
        self$deliver(reply)
    }
}

#' `textDocument/inlayHint` request handler
#' @noRd
text_document_inlay_hint <- function(self, id, params) {
    uri <- uri_escape_unicode(params$textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))

    reply <- inlay_hint_reply(id, uri, workspace, document, params$range)
    if (is.null(reply)) {
        enqueue_latest_reply(self, uri, "textDocument/inlayHint", list(
            id = id, version = document$version, params = params))
    } else {
        self$deliver(reply)
    }
}

#' `inlayHint/resolve` request handler
#' @noRd
inlay_hint_resolve <- function(self, id, params) {
    workspace <- self$get_workspace(params$data$uri)
    self$deliver(inlay_hint_resolve_reply(id, workspace, params))
}

#' `textDocument/semanticTokens/full` request handler
#'
#' Handler to the `textDocument/semanticTokens/full` [Request].
#' @noRd
text_document_semantic_tokens_full <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    reply <- semantic_tokens_full_reply(id, uri, workspace, document)
    if (is.null(reply)) {
        enqueue_latest_reply(self, uri, "textDocument/semanticTokens/full", list(
            id = id,
            version = document$version,
            params = params
        ))
    } else {
        self$deliver(reply)
    }
}

#' `textDocument/semanticTokens/full/delta` request handler
#' @noRd
text_document_semantic_tokens_delta <- function(self, id, params) {
    uri <- uri_escape_unicode(params$textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) {
        return(self$deliver(Response$new(id = id, result = NULL)))
    }
    reply <- semantic_tokens_delta_reply(
        id, uri, workspace, document, params$previousResultId)
    if (is.null(reply)) {
        enqueue_latest_reply(
            self, uri, "textDocument/semanticTokens/full/delta", list(
            id = id,
            version = document$version,
            params = params
        ))
    } else {
        self$deliver(reply)
    }
}

#' `textDocument/semanticTokens/range` request handler
#'
#' Handler to the `textDocument/semanticTokens/range` [Request].
#' @noRd
text_document_semantic_tokens_range <- function(self, id, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    workspace <- self$get_workspace(uri)
    document <- workspace$documents$get(uri)
    if (is.null(document)) return(self$deliver(Response$new(id = id, result = NULL)))
    reply <- semantic_tokens_range_reply(id, uri, workspace, document, params$range)
    if (is.null(reply)) {
        enqueue_latest_reply(self, uri, "textDocument/semanticTokens/range", list(
            id = id,
            version = document$version,
            params = params
        ))
    } else {
        self$deliver(reply)
    }
}

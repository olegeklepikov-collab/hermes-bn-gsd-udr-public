#' `textDocument/didOpen` notification handler
#'
#' Handler to the `textDocument/didOpen` [Notification].
#' @noRd
update_document_index <- function(self, workspace, uri, content,
    cacheable = FALSE) {
    if (is.null(workspace$index) || !isTRUE(workspace$index$enabled)) {
        return(invisible(NULL))
    }
    workspace$index$update_content(uri, content, cacheable = cacheable)
    self$refresh_index_documents(workspace, uri)
    invisible(NULL)
}

text_document_did_open <- function(self, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    cancel_formatting_requests(self, uri = uri,
        message = "Request superseded by a reopened document")
    language <- textDocument$languageId
    version <- textDocument$version
    text <- textDocument$text
    logger$info("did open:", list(uri = uri, version = version))
    path <- path_from_uri(uri)
    if (!is.null(text)) {
        content <- stringi::stri_split_lines(text)[[1]]
    } else if (file.exists(path)) {
        content <- stringi::stri_read_lines(path)
    } else {
        content <- NULL
    }
    
    workspace <- self$get_workspace(uri)

    if (workspace$documents$has(uri)) {
        doc <- workspace$documents$remove(uri)
    }
    doc <- Document$new(uri, language = language, version = version, content = content)
    workspace$documents$set(uri, doc)
    doc$did_open()
    update_document_index(self, workspace, uri, doc$content)
    # Performance: Parse immediately on open (no delay) to have data ready for initial requests
    self$text_sync(uri, document = doc, run_lintr = TRUE, parse = TRUE, delay = 0)
}

#' `textDocument/didChange` notification handler
#'
#' Handler to the `textDocument/didChange` [Notification].
#' @noRd
text_document_did_change <- function(self, params) {
    textDocument <- params$textDocument
    contentChanges <- params$contentChanges
    uri <- uri_escape_unicode(textDocument$uri)
    version <- textDocument$version
    logger$info("did change:", list(uri = uri, version = version))
    cancel_formatting_requests(self, uri = uri,
        message = "Request superseded by a newer document version")

    pending <- self$pending_replies$get(uri, NULL)
    for (queue in pending) {
        retained <- list()
        while (queue$size()) {
            item <- queue$pop()
            if (!is.null(item$version) && item$version < version) {
                self$deliver(ResponseErrorMessage$new(
                    item$id,
                    "RequestCancelled",
                    "Request superseded by a newer document version"
                ))
            } else {
                retained[[length(retained) + 1L]] <- item
            }
        }
        for (item in retained) queue$push(item)
    }
    
    workspace <- self$get_workspace(uri)

    if (workspace$documents$has(uri)) {
        doc <- workspace$documents$get(uri)
        doc$apply_content_changes(version, contentChanges)
    } else {
        # Incremental changes are only valid for an open document. Be
        # tolerant of a client that sends a full replacement before didOpen.
        full_change <- Filter(function(change) is.null(change$range), contentChanges)
        content <- if (length(full_change)) {
            stringi::stri_split_lines(full_change[[length(full_change)]]$text)[[1]]
        } else {
            ""
        }
        doc <- Document$new(uri, language = NULL, version = version, content = content)
        workspace$documents$set(uri, doc)
    }
    doc$did_open()
    # The accepted background parse updates definitions and source edges.
    # Parsing a shallow index here would block every keystroke a second time.
    self$text_sync(
        uri,
        document = doc,
        run_lintr = TRUE,
        parse = TRUE,
        parse_delay = lsp_settings$get("parse_delay"),
        diagnostics_delay = lsp_settings$get("diagnostics_delay")
    )
}

#' `textDocument/willSave` notification handler
#'
#' Handler to the `textDocument/willSave` [Notification].
#' @noRd
text_document_will_save <- function(self, params) {

}

#' `textDocument/didSave` notification handler
#'
#' Handler to the `textDocument/didSave` [Notification].
#' @noRd
text_document_did_save <- function(self, params) {
    textDocument <- params[["textDocument"]]
    text <- params[["text"]]
    uri <- uri_escape_unicode(textDocument[["uri"]])
    logger$info("did save:", list(uri = uri))

    workspace <- self$get_workspace(uri)

    # https://github.com/microsoft/language-server-protocol/issues/2110
    # follow dbaeumer's take on not handling files that weren't claimed before didSave
    if (!workspace$documents$has(uri)) {
        return(NULL)
    }

    path <- path_from_uri(uri)
    if (!is.null(text)) {
        content <- stringi::stri_split_lines(text)[[1]]
    } else if (file.exists(path)) {
        content <- stringi::stri_read_lines(path)
    } else {
        content <- NULL
    }
    doc <- workspace$documents$get(uri)
    if (!identical(doc$content, content)) {
        cancel_formatting_requests(self, uri = uri,
            message = "Request superseded by updated document content")
    }
    doc$set_content(doc$version, content)
    doc$did_open()
    update_document_index(
        self, workspace, uri, doc$content, cacheable = TRUE)
    self$text_sync(uri, document = doc, run_lintr = TRUE, parse = TRUE)
}

#' `textDocument/didClose` notification handler
#'
#' Handler to the `textDocument/didClose` [Notification].
#' @noRd
text_document_did_close <- function(self, params) {
    textDocument <- params$textDocument
    uri <- uri_escape_unicode(textDocument$uri)
    cancel_formatting_requests(self, uri = uri,
        message = "Request cancelled because the document was closed")
    path <- path_from_uri(uri)
    
    workspace <- self$get_workspace(uri)
    
    is_from_workspace <- path_has_parent(path, workspace$root)

    # remove diagnostics if file is not from workspace
    if (!is_from_workspace) {
        diagnostics_callback(self, uri, NULL, list())
    }

    # mark document as closed so that
    # workspace_did_change_watched_files will not ignore it
    if (workspace$documents$has(uri)) {
        doc <- workspace$documents$get(uri)
        doc$did_close()
    }

    if (!is.null(workspace$index) && isTRUE(workspace$index$enabled)) {
        if (file.exists(path)) {
            workspace$index$update_path(path)
        } else {
            workspace$index$remove(uri)
        }
        self$prune_index_documents(workspace)
    # do not remove document in package
    } else if (!(is_package(workspace$root) && is_from_workspace)) {
        diagnostics_callback(self, uri, NULL, list())
        workspace$documents$remove(uri)
        workspace$diagnostics_globals_cache <- NULL
        workspace$type_hierarchy_cache$clear()
        workspace$update_loaded_packages()
    }

    self$pending_replies$remove(uri)
}

#' `textDocument/willSaveWaitUntil` notification handler
#'
#' Handler to the `textDocument/willSaveWaitUntil` [Request].
#' @noRd
text_document_will_save_wait_until <- function(self, id, params) {

}

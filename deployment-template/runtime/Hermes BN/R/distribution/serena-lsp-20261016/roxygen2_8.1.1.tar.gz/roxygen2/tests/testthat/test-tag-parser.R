test_that("tags containing only whitespace generate warning", {
  expect_snapshot({
    tag <- roxy_test_tag(" ")
    expect_parse_failure(tag_value(tag))
    expect_parse_failure(tag_inherit(tag))
    expect_parse_failure(tag_name(tag))
    expect_parse_failure(tag_name_description(tag))
    expect_parse_failure(tag_code(tag))
    expect_parse_failure(tag_examples(tag))
    expect_parse_failure(tag_markdown(tag))
    expect_parse_failure(tag_markdown_with_sections(tag))
  })
})

test_that("tags check for mismatched parents gives useful warnings", {
  expect_snapshot({
    tag <- roxy_test_tag("a {")
    expect_parse_failure(tag_value(tag))
    expect_parse_failure(tag_inherit(tag))
    expect_parse_failure(tag_name(tag))
    expect_parse_failure(tag_two_part(tag))
    expect_parse_failure(tag_words(tag))
    expect_parse_failure(tag_examples(tag))

    "markdown tags return empty values"
    tag_markdown(tag)
    tag_markdown_with_sections(tag)
  })

  local_markdown()
  markdown_on()
  expect_snapshot({
    tag <- roxy_test_tag("# one\ntwo\n# three\nfour {")
    tag_markdown_with_sections(tag)
  })
})

test_that("tag_inhert checks for valid inherits", {
  expect_snapshot({
    tag <- roxy_test_tag("foo params section")
    . <- tag_inherit(tag)
  })
})

test_that("tag_name() checks for valid names", {
  expect_snapshot({
    tag <- roxy_test_tag("a b c")
    expect_parse_failure(tag_name(tag))
  })
})

test_that("tag_two_part() gives useful warnings", {
  local_markdown()
  expect_snapshot({
    tag <- roxy_test_tag("")
    expect_parse_failure(tag_two_part(
      tag,
      "a name",
      "a value",
      required = FALSE
    ))
    expect_parse_failure(tag_two_part(tag, "a name", "a value"))
  })
})

test_that("tag_two_part() falls back to space split for unclosed backtick", {
  tag <- roxy_test_tag("`unclosed description")
  out <- tag_two_part(tag, "a name", "a value", required = FALSE)
  expect_equal(out$val, list(name = "`unclosed", description = "description"))
})

test_that("tag_words() gives useful warnings", {
  expect_snapshot({
    tag <- roxy_test_tag("a b")
    expect_parse_failure(tag_words(tag, 3, 3))
    expect_parse_failure(tag_words(tag, 1, 1))
  })
})

test_that("tag_words() warns on multi-line content and preserves value", {
  expect_snapshot({
    tag <- roxy_test_tag("a\nb")
    out <- tag_words(tag)
  })
  expect_equal(out$val, c("a", "b"))
})

test_that("tag_two_part() warns on multi-line content and preserves value", {
  expect_snapshot({
    tag <- roxy_test_tag("foo bar\nbaz")
    out <- tag_two_part(tag, "a name", "a value")
  })
  expect_equal(out$val, list(name = "foo", description = "bar\nbaz"))

  tag <- roxy_test_tag("foo bar\nbaz")
  out <- expect_silent(tag_two_part(tag, "a name", "a value", multiline = TRUE))
  expect_equal(out$val, list(name = "foo", description = "bar\nbaz"))
})

test_that("multiline accepts string strategies and legacy booleans", {
  expect_equal(as_multiline("never"), "never")
  expect_equal(as_multiline("indent"), "indent")
  expect_equal(as_multiline("always"), "always")
  expect_equal(as_multiline(FALSE), "never")
  expect_equal(as_multiline(TRUE), "always")
  expect_error(as_multiline("nope"))
})

test_that("tag_value() warns on multi-line content and preserves value", {
  expect_snapshot({
    tag <- roxy_test_tag("a\nb")
    out <- tag_value(tag)
  })
  expect_equal(out$val, "a\nb")
})

test_that("tag_words_line() is deprecated", {
  expect_snapshot({
    tag <- roxy_test_tag("a b")
    tag_words_line(tag)
  })
})

test_that("tag_toggle() gives useful warnings", {
  expect_snapshot({
    tag <- roxy_test_tag("x")
    tag_toggle(tag)
  })
})

test_that("tag_code() gives useful warnings", {
  expect_snapshot({
    tag <- roxy_test_tag("a + ")
    tag_code(tag)
  })
})

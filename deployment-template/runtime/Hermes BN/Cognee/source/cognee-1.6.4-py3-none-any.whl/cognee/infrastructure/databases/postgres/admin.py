"""Postgres admin operations against the cluster's 'postgres' maintenance database.

These helpers handle the boilerplate of opening an AUTOCOMMIT connection to the
admin DB, running a CREATE/DROP DATABASE statement, and disposing of the
maintenance engine. Callers supply connection credentials directly; this module
is intentionally agnostic about which subsystem (graph, vector, dlt) the
credentials came from.
"""

import json
import os
import re
from uuid import UUID

from sqlalchemy import URL, text
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.schema import DDLElement

_MAINTENANCE_DB_NAME = "postgres"

# Advisory locks that make the create helpers atomic across every process in
# the cluster: a fixed namespace hash plus the hash of the resource being
# provisioned. Session-level for CREATE DATABASE, which cannot run inside a
# transaction; transaction-level for schema DDL, released with the transaction.
_ACQUIRE_PROVISIONING_LOCK = (
    "SELECT pg_advisory_lock(hashtext('cognee_provisioning'), hashtext(:key))"
)
_RELEASE_PROVISIONING_LOCK = (
    "SELECT pg_advisory_unlock(hashtext('cognee_provisioning'), hashtext(:key))"
)
_ACQUIRE_PROVISIONING_XACT_LOCK = (
    "SELECT pg_advisory_xact_lock(hashtext('cognee_provisioning'), hashtext(:key))"
)
# Dataset databases are named after dataset UUIDs (hyphens, leading digits), so
# this is looser than an unquoted Postgres identifier; the compiled DDL below
# always quotes the name via compiler.preparer.quote, which is what actually
# prevents injection. The regex still rejects quotes, whitespace, and other
# metacharacters as defense in depth, and enforces the 63-byte name limit.
_POSTGRES_IDENTIFIER_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_$-]{0,62}$")


def _validate_database_identifier(db_name: str) -> str:
    if not _POSTGRES_IDENTIFIER_RE.fullmatch(db_name):
        raise ValueError("Invalid Postgres database name")
    return db_name


class CreateDatabase(DDLElement):
    def __init__(self, db_name: str) -> None:
        self.db_name = _validate_database_identifier(db_name)


class DropDatabaseIfExists(DDLElement):
    def __init__(self, db_name: str) -> None:
        self.db_name = _validate_database_identifier(db_name)


@compiles(CreateDatabase)
def _compile_create_database(element: CreateDatabase, compiler, **kwargs) -> str:
    return "CREATE DATABASE " + compiler.preparer.quote(element.db_name)


@compiles(DropDatabaseIfExists)
def _compile_drop_database_if_exists(element: DropDatabaseIfExists, compiler, **kwargs) -> str:
    return "DROP DATABASE IF EXISTS " + compiler.preparer.quote(element.db_name)


def dataset_schema_name(dataset_id: UUID | str) -> str:
    """Postgres schema name used to isolate a dataset in shared-database mode.

    Returns ``ds_<dataset_id_hex>`` — a valid, lower-case Postgres identifier
    (``ds_`` + 32 hex chars = 35 chars, well under the 63-char limit). The
    leading ``ds_`` keeps the name a valid identifier even though a raw UUID
    starts with a digit, and namespaces these schemas so they never collide
    with ``public`` or cognee's relational tables.
    """
    raw = dataset_id.hex if isinstance(dataset_id, UUID) else str(dataset_id).replace("-", "")
    return f"ds_{raw}"


def _admin_connect_args() -> dict:
    """SSL/connect args for the maintenance engine, from DATABASE_CONNECT_ARGS.

    Managed Postgres (e.g. Neon, RDS) requires SSL,
    but asyncpg uses ``ssl`` not ``sslmode``. Returns {} for in-cluster Postgres
    (env unset) so this stays a no-op there.
    """
    raw = os.environ.get("DATABASE_CONNECT_ARGS")
    if not raw:
        return {}
    try:
        args = json.loads(raw)
    except (ValueError, TypeError):
        return {}
    out = {}
    if args.get("ssl") is not None:
        out["ssl"] = args["ssl"]
    elif args.get("sslmode") is not None:  # map libpq sslmode -> asyncpg ssl
        out["ssl"] = args["sslmode"]
    return out


def _direct_host(host: str) -> str:
    """CREATE/DROP DATABASE can't run through Neon's PgBouncer pooler — use the
    direct endpoint. No-op for non-Neon hosts."""
    return host.replace("-pooler.", ".") if host and "-pooler." in host else host


def _build_maintenance_url(host: str, port: int | str, username: str, password: str) -> URL:
    return URL.create(
        "postgresql+asyncpg",
        username=username,
        password=password,
        host=_direct_host(host),
        port=int(port),
        database=_MAINTENANCE_DB_NAME,
    )


def _build_db_url(db_name: str, host: str, port: int | str, username: str, password: str) -> URL:
    """Connection URL to a specific (already existing) database.

    Unlike ``_build_maintenance_url`` this targets ``db_name`` directly, since
    schema DDL (CREATE/DROP SCHEMA) runs inside the target database rather than
    against the cluster's maintenance database.
    """
    return URL.create(
        "postgresql+asyncpg",
        username=username,
        password=password,
        host=_direct_host(host),
        port=int(port),
        database=db_name,
    )


async def create_pg_schema_if_not_exists(
    db_name: str,
    schema: str,
    host: str,
    port: int | str,
    username: str,
    password: str,
    with_vector_extension: bool = False,
) -> None:
    """Create a Postgres schema inside ``db_name`` if it does not already exist.

    Used by the shared-database dataset handlers, which isolate each dataset in
    its own schema (``ds_<dataset_id>``) inside one shared database instead of
    provisioning a whole database per dataset. When ``with_vector_extension`` is
    set the pgvector extension is ensured in the database (it installs into the
    database's ``public`` schema and is reachable from any schema via the
    search path).

    Safe to call concurrently: IF NOT EXISTS is not race-free in Postgres (two
    transactions that both pass the check collide on the catalog's unique
    index), so creators are serialized on an advisory lock keyed by the shared
    database, which also covers the extension.
    """
    engine = create_async_engine(
        _build_db_url(db_name, host, port, username, password),
        connect_args=_admin_connect_args(),
    )
    try:
        async with engine.begin() as connection:
            await connection.execute(text(_ACQUIRE_PROVISIONING_XACT_LOCK), {"key": db_name})
            if with_vector_extension:
                await connection.execute(text("CREATE EXTENSION IF NOT EXISTS vector;"))
            await connection.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema}";'))
    finally:
        await engine.dispose()


async def drop_pg_schema_if_exists(
    db_name: str,
    schema: str,
    host: str,
    port: int | str,
    username: str,
    password: str,
) -> None:
    """Drop a dataset schema (and everything in it) from ``db_name``.

    ``DROP SCHEMA ... CASCADE`` removes every table/index the dataset created,
    giving the shared-database handlers an atomic, single-statement cleanup that
    mirrors ``drop_pg_database_if_exists`` for the database-per-dataset mode.
    """
    engine = create_async_engine(
        _build_db_url(db_name, host, port, username, password),
        connect_args=_admin_connect_args(),
    )
    try:
        async with engine.begin() as connection:
            await connection.execute(text(f'DROP SCHEMA IF EXISTS "{schema}" CASCADE;'))
    finally:
        await engine.dispose()


async def create_pg_database_if_not_exists(
    db_name: str,
    host: str,
    port: int | str,
    username: str,
    password: str,
) -> bool:
    """Create a Postgres database if it does not already exist.

    Connects to the cluster's 'postgres' maintenance database in AUTOCOMMIT
    mode and runs ``CREATE DATABASE`` guarded by an existence check. The check
    and the create are made atomic with a session-level advisory lock on the
    database name (``CREATE DATABASE`` has no ``IF NOT EXISTS``), so concurrent
    callers create the database once; Postgres releases the lock if the
    connection drops.

    Returns:
        True if the database was created, False if it already existed.
    """
    engine = create_async_engine(
        _build_maintenance_url(host, port, username, password),
        connect_args=_admin_connect_args(),
    )
    try:
        connection = await engine.connect()
        try:
            connection = await connection.execution_options(isolation_level="AUTOCOMMIT")
            await connection.execute(text(_ACQUIRE_PROVISIONING_LOCK), {"key": db_name})
            try:
                result = await connection.execute(
                    text("SELECT 1 FROM pg_database WHERE datname = :db"),
                    {"db": db_name},
                )
                if result.scalar():
                    return False
                await connection.execute(CreateDatabase(db_name))
                return True
            finally:
                await connection.execute(text(_RELEASE_PROVISIONING_LOCK), {"key": db_name})
        finally:
            await connection.close()
    finally:
        await engine.dispose()


async def drop_pg_database_if_exists(
    db_name: str,
    host: str,
    port: int | str,
    username: str,
    password: str,
) -> None:
    """Drop a Postgres database after terminating any active backends.

    Connects to the cluster's 'postgres' maintenance database in AUTOCOMMIT
    mode, terminates every backend currently connected to ``db_name`` other
    than our own, then runs ``DROP DATABASE IF EXISTS``.
    """
    engine = create_async_engine(
        _build_maintenance_url(host, port, username, password),
        connect_args=_admin_connect_args(),
    )
    try:
        connection = await engine.connect()
        try:
            connection = await connection.execution_options(isolation_level="AUTOCOMMIT")
            await connection.execute(
                text(
                    "SELECT pg_terminate_backend(pid) "
                    "FROM pg_stat_activity "
                    "WHERE datname = :db AND pid <> pg_backend_pid()"
                ),
                {"db": db_name},
            )
            await connection.execute(DropDatabaseIfExists(db_name))
        finally:
            await connection.close()
    finally:
        await engine.dispose()

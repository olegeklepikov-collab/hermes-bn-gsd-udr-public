#' Print a web page to PDF/PNG/JPEG
#'
#' Print a web page to PDF or take a screenshot to PNG/JPEG via a headless
#' browser such as Chromium or Google Chrome.
#' @param input Path or URL to the HTML page to be printed.
#' @param output An output filename. If only an extension is provided, the
#'   filename will be inferred from `url` via [url_filename()]. Only `.pdf`,
#'   `.png`, and `.jpeg` are supported.
#' @param args Command-line arguments to be passed to the headless browser. The
#'   default arguments can be found in `xfun:::browser_args()`. You may pass
#'   additional arguments on top of these via, e.g., `c('default',
#'   '--force-device-scale-factor=2')`, or completely override the default
#'   arguments by providing a vector of other arguments.
#' @param window_size The browser window size when taking a PNG/JPEG screenshot.
#'   Ignored when printing to PDF.
#' @param browser Path to the web browser. By default, the browser is found via
#'   `xfun:::find_browser()`. If it cannot be found, you may set the global
#'   option `options(xfun.browser = )` or environment variable `R_XFUN_BROWSER`
#'   to the path of the browser, or simply pass the path to the `browser`
#'   argument.
#' @return The `output` path if the web page is successfully printed.
#' @export
#' @examplesIf interactive()
#' xfun::browser_print("https://www.r-project.org")
browser_print = function(
  input, output = '.pdf', args = 'default', window_size = c(1280, 1024),
  browser = NULL
) {
  browser = check_browser(browser)
  if (sans_ext(output) == '') output = with_ext(url_filename(input), output)
  to_pdf = tolower(file_ext(output)) == 'pdf'
  if (!to_pdf && !any(grepl('--window-size=', args)))
    args = c(args, paste0('--window-size=', paste(window_size, collapse = ',')))
  if ('default' %in% args) {
    args = setdiff(c(
      args, browser_args(),
      # Chromium otherwise stamps the date, page title, and file path into the
      # PDF's header and footer, which is just noise for programmatic printing.
      if (to_pdf) '--no-pdf-header-footer'
    ), 'default')
  }
  args = c(args, sprintf(
    '--%s="%s"', if (to_pdf) 'print-to-pdf' else 'screenshot', normalize_path(output)
  ), shQuote(input))
  if (with_browser_tmp(system2(browser, args, stderr = FALSE)) != 0)
    stop('Failed to print to ', output)
  output
}

#' Execute JavaScript on an HTML page via a headless browser and dump the DOM
#'
#' Load an HTML page in a headless browser (Chromium/Chrome/Edge), execute all
#' JavaScript on it, and return (or save) the rendered DOM as HTML.
#' @param input Path or URL to the HTML page.
#' @param output An optional output file path. If not provided, the rendered
#'   HTML is returned as a character string.
#' @param fragment Whether to return only the inner body content instead of the
#'   full HTML document.
#' @inheritParams browser_print
#' @return If `output` is `NULL`, the rendered HTML as a character string;
#'   otherwise the `output` path (invisibly).
#' @export
#' @examplesIf interactive()
#' f = tempfile(fileext = ".html")
#' writeLines(c(
#'   '<html><body><div id="out"></div>',
#'   '<script>document.getElementById("out").textContent = "hello";</script>',
#'   '</body></html>'
#' ), f)
#' xfun::browser_dom(f)
browser_dom = function(input, output = NULL, fragment = FALSE, browser = NULL) {
  browser = check_browser(browser)
  args = c(browser_args(), '--dump-dom', '--log-level=3', input)
  html = with_browser_tmp(system2(browser, args, stdout = TRUE, stderr = FALSE))
  if (!is.null(attr2(html, 'status'))) stop('Failed to dump DOM.')
  html = gsub('\\s*<script[^>]*>(?s).*?</script>\\s*', '', one_string(html), perl = TRUE)
  if (fragment)
    html = gsub('^(?s).*?<body[^>]*>\\s*|\\s*</body>(?s).*$', '', html, perl = TRUE)
  if (is.null(output)) raw_string(html) else write_utf8(html, output)
}

# Evaluate `expr` (a headless-browser command) with the browser pointed at a
# private, disposable temp directory. Chromium scatters scratch files (e.g.
# 'com.google.Chrome.*') into TMPDIR and does not always remove them when it
# exits; confining them to a directory we delete afterward keeps the temp dir
# clean (e.g. so R CMD check does not report detritus).
with_browser_tmp = function(expr) {
  d = tempfile('browser-'); dir.create(d)
  old = set_envvar(c(TMPDIR = d))
  on.exit({ set_envvar(old); unlink(d, recursive = TRUE, force = TRUE) }, add = TRUE)
  expr
}

check_browser = function(browser) {
  if (is.null(browser)) browser = env_option('xfun.browser', find_browser())
  if (!file.exists(browser)) browser = Sys.which(browser)
  if (!utils::file_test('-x', browser)) stop('The browser is not executable: ', browser)
  browser
}

browser_args = function() c(
  proxy_args(), if (is_windows()) '--no-sandbox', '--headless',
  '--no-first-run', '--no-default-browser-check', '--hide-scrollbars',
  # avoid spawning the component/CRX URL fetcher, which leaves temp files
  # (e.g., 'com.google.Chrome.chromecrx_chrome_url_fetcher_*') behind
  '--disable-background-networking', '--disable-component-update'
)

find_browser = function() {
  switch(
    .Platform$OS.type,
    windows = {
      res = unlist(lapply(c('ChromeHTML', 'MSEdgeHTM'), function(x) {
        res = tryCatch({
          unlist(utils::readRegistry(sprintf('%s\\shell\\open\\command', x), 'HCR'))
        }, error = function(e) '')
        res = unlist(strsplit(res, '"'))
        res = head(res[file.exists(res)], 1)
      }))
      if (length(res) == 0) stop(
        'Cannot find Google Chrome or Edge automatically from the Windows Registry Hive. ',
        "Please pass the full path of chrome.exe or msedge.exe to the 'browser' argument ",
        "or to the environment variable 'R_XFUN_BROWSER'."
      )
      res[1]
    },
    unix = {
      app_path = function(app) sprintf('/Applications/%s.app/Contents/MacOS/%s', app, app)
      for (i in c(
        app_path(c('Google Chrome', 'Microsoft Edge')),
        'google-chrome', 'chromium-browser', 'chromium', 'google-chrome-stable',
        'microsoft-edge-stable', 'microsoft-edge')) {
        if ((res <- Sys.which(i)) != '') break
      }
      if (res == '') stop('Cannot find Chromium, Google Chrome, or Edge')
      res
    },
    stop('Your platform is not supported')
  )
}

proxy_args = function() {
  x = Sys.getenv(c('https_proxy', 'HTTPS_PROXY', 'http_proxy', 'HTTP_PROXY'))
  x = x[x != '']
  if (length(x) == 0) return()
  c(
    paste0('--proxy-server=', x[1]),
    shQuote(paste0('--proxy-bypass-list=', paste(no_proxy(), collapse = ';')))
  )
}

no_proxy = function() {
  x = do.call(c, strsplit(Sys.getenv(c('no_proxy', 'NO_PROXY')), '[,;]'))
  x = c('localhost', '127.0.0.1', x)
  unique(x)
}


hover_xpath <- paste(
    "(* | descendant-or-self::expr | descendant-or-self::expr_or_assign_or_help)[self::FUNCTION or self::OP-LAMBDA][following-sibling::SYMBOL_FORMALS[text() = '{token_quote}' and @line1 <= {row}]]/parent::expr",
    "(* | descendant-or-self::expr | descendant-or-self::expr_or_assign_or_help)[LEFT_ASSIGN[preceding-sibling::expr[count(*)=1]/SYMBOL[text() = '{token_quote}' and @line1 <= {row}] and following-sibling::expr[@start > {start} or @end < {end}]]]",
    "(* | descendant-or-self::expr | descendant-or-self::expr_or_assign_or_help)[RIGHT_ASSIGN[following-sibling::expr[count(*)=1]/SYMBOL[text() = '{token_quote}' and @line1 <= {row}] and preceding-sibling::expr[@start > {start} or @end < {end}]]]",
    "(* | descendant-or-self::expr | descendant-or-self::expr_or_assign_or_help)[EQ_ASSIGN[preceding-sibling::expr[count(*)=1]/SYMBOL[text() = '{token_quote}' and @line1 <= {row}] and following-sibling::expr[@start > {start} or @end < {end}]]]",
    "forcond/SYMBOL[text() = '{token_quote}' and @line1 <= {row}]",
    sep = "|")

#' Format hover contents for a function argument
#' @noRd
function_argument_hover_contents <- function(workspace, funct, package, parameter,
    uri = NULL) {
    doc <- if (is.null(uri)) {
        workspace$get_documentation(funct, package, isf = TRUE)
    } else {
        call_with_optional_uri(
            workspace$get_documentation,
            funct, package, isf = TRUE, uri = uri)
    }
    if (!is.list(doc)) return(NULL)

    doc_string <- doc$arguments[[parameter]]
    if (is.null(doc_string)) {
        doc_string <- doc$arguments$...
        parameter <- "..."
    }
    if (is.null(doc_string)) return(NULL)

    sig <- if (is.null(uri)) workspace$get_signature(funct, package)
    else call_with_optional_uri(
        workspace$get_signature, funct, package, uri = uri)
    if (is.null(sig)) return(doc_string)

    c(
        sprintf("```r\n%s\n```", str_trunc(sig, 300)),
        sprintf("`%s` - %s", parameter, doc_string)
    )
}

#' The response to a textDocument/hover Request
#'
#' When hovering on a symbol, if it is a function, return its help text
#' if it exists in the current [Workspace].
#' @noRd
hover_reply <- function(id, uri, workspace, document, point) {
    if (!check_scope(uri, document, point)) {
        return(Response$new(id))
    }

    token_result <- document$detect_token(point)
    range <- token_result$range

    contents <- NULL
    resolved <- FALSE

    version <- workspace$get_parse_data(uri)$version
    logger$info("hover:", list(uri = uri, version = version, token = token_result))

    xdoc <- workspace$get_parse_data(uri)$xml_doc

    if (token_result$accessor == "" && !is.null(xdoc)) {
        row <- point$row + 1
        col <- point$col + 1
        token <- xdoc_find_token(xdoc, row, col)
        if (length(token)) {
            token_name <- xml_name(token)
            token_text <- xml_text(token)
            token_start <- as.integer(xml_attr(token, "start"))
            token_end <- as.integer(xml_attr(token, "end"))
            logger$info(token_name, token_text)
            if (token_name %in% c("SYMBOL", "SYMBOL_FUNCTION_CALL")) {
                # symbol
                preceding_dollar <- xml_find_first(token, "preceding-sibling::OP-DOLLAR")
                if (length(preceding_dollar) == 0) {
                    xpath <- glue(hover_xpath,
                        row = row, start = token_start, end = token_end,
                        token_quote = xml_single_quote(token_text))
                    all_defs <- xdoc_find_definitions(xdoc, row, col, token_text, xpath)
                    if (length(all_defs)) {
                        last_def <- all_defs[[length(all_defs)]]
                        def_func <- xml_find_first(last_def,
                            "self::*[LEFT_ASSIGN | RIGHT_ASSIGN | EQ_ASSIGN]/expr[FUNCTION | OP-LAMBDA]")
                        if (length(def_func)) {
                            func_line1 <- as.integer(xml_attr(def_func, "line1"))
                            def_text <- local_function_signature(document, def_func, token_text)
                            def_line1 <- func_line1
                        } else {
                            def_line1 <- as.integer(xml_attr(last_def, "line1"))
                            def_line2 <- def_line1
                            def_text <- trimws(
                                paste0(document$content[def_line1:def_line2],
                                    collapse = "\n")
                            )
                        }
                        doc_string <- NULL
                        doc_line1 <- detect_comments(document$content, def_line1 - 1) + 1
                        if (doc_line1 < def_line1) {
                            comment <- document$content[doc_line1:(def_line1 - 1)]
                            doc <- convert_comment_to_documentation(comment)
                            if (is.character(doc)) {
                                doc_string <- doc
                            } else if (is.list(doc)) {
                                if (is.null(doc$markdown)) {
                                    doc_string <- doc$description
                                } else {
                                    doc_string <- doc$markdown
                                }
                            }
                        }
                        contents <- c(sprintf("```r\n%s\n```", def_text), doc_string)
                        resolved <- TRUE
                    }
                }
            } else if (token_name == "SYMBOL_SUB") {
                # function parameter
                funct <- xml_text(xml_find_first(token,
                    "preceding-sibling::expr/SYMBOL_FUNCTION_CALL/text()"))
                if (!is.na(funct)) {
                    package <- xml_text(xml_find_first(token,
                        "preceding-sibling::expr/SYMBOL_PACKAGE/text()"))
                    if (is.na(package)) {
                        package <- NULL
                        xpath <- glue(signature_xpath, row = row,
                            token_quote = xml_single_quote(funct))
                        all_defs <- xdoc_find_definitions(xdoc, row, col, funct, xpath)
                        if (length(all_defs)) {
                            last_def <- all_defs[[length(all_defs)]]
                            func_line1 <- as.integer(xml_attr(last_def, "line1"))
                            sig <- local_function_signature(document, last_def, funct)
                            doc_string <- NULL

                            doc_line1 <- detect_comments(document$content, func_line1 - 1) + 1
                            if (doc_line1 < func_line1) {
                                comment <- document$content[doc_line1:(func_line1 - 1)]
                                doc <- convert_comment_to_documentation(comment)
                                if (is.list(doc)) {
                                    doc_string <- doc$arguments[[token_text]]
                                    if (!is.null(doc_string)) {
                                        contents <- c(
                                            sprintf("```r\n%s\n```", sig),
                                            sprintf("`%s` - %s", token_text, doc_string))
                                    }
                                }
                            }

                            resolved <- TRUE
                        }
                    }

                    if (!resolved) {
                        contents <- function_argument_hover_contents(
                            workspace, funct, package, token_text, uri = uri)
                        resolved <- TRUE
                    }
                }
            } else if (token_name == "SYMBOL_FORMALS") {
                # function formals
                funct <- xml_find_first(token, "preceding-sibling::*[self::FUNCTION or self::OP-LAMBDA]/parent::expr")
                func_line1 <- as.integer(xml_attr(funct, "line1"))
                doc_line1 <- detect_comments(document$content, func_line1 - 1) + 1

                if (doc_line1 < func_line1) {
                    comment <- document$content[doc_line1:(func_line1 - 1)]
                    doc <- convert_comment_to_documentation(comment)
                    if (is.list(doc)) {
                        doc_string <- doc$arguments[[token_text]]
                        if (!is.null(doc_string)) {
                            contents <- sprintf("`%s` - %s", token_text, doc_string)
                        }
                    }
                }

                resolved <- TRUE
            } else if (token_name == "SYMBOL_PACKAGE") {
                # package
                if (length(find.package(token_text, quiet = TRUE))) {
                    desc <- utils::packageDescription(token_text, fields = c("Title", "Description"))
                    description <- gsub("\\s*\n\\s*", " ", desc$Description)
                    contents <- sprintf("**%s**\n\n%s", desc$Title, description)
                } else {
                    contents <- sprintf("Package `%s` is not installed.", token_text)
                }
                resolved <- TRUE
            } else if (token_name == "SLOT") {
                # S4 slot
                resolved <- TRUE
            } else if (token_name == "NUM_CONST") {
                # logical, integer, double
                # contents <- "number"
                # resolved <- TRUE
            } else if (token_name == "STR_CONST") {
                # string literal
                # contents <- "string"
                resolved <- TRUE
            } else if (token_name == "COMMENT") {
                # comment
                resolved <- TRUE
            } else if (startsWith(token_name, "OP-")) {
                # operators
                resolved <- TRUE
            }
        }
    }

    if (!resolved) {
        contents <- call_with_optional_uri(
            workspace$get_help,
            token_result$token, token_result$package, uri = uri)
        if (is.null(contents)) {
            def_text <- NULL

            doc <- call_with_optional_uri(
                workspace$get_documentation,
                token_result$token, token_result$package, uri = uri)
            signs <- if (is.null(token_result$package)) {
                call_with_optional_uri(
                    workspace$guess_namespace, token_result$token, uri = uri)
            } else {
                token_result$package
            }
            sig <- call_with_optional_uri(
                workspace$get_signature,
                token_result$token, signs,
                exported_only = token_result$accessor != ":::", uri = uri)

            if (is.null(sig)) {
                def <- call_with_optional_uri(
                    workspace$get_definition,
                    token_result$token, token_result$package,
                    exported_only = token_result$accessor != ":::", uri = uri)
                if (!is.null(def)) {
                    def_doc <- workspace$documents$get(def$uri)
                    def_line1 <- def$range$start$line + 1
                    def_text <- def_doc$line(def_line1)
                }
            } else {
                def_text <- sig
            }

            doc_string <- NULL
            if (is.character(doc)) {
                doc_string <- doc
            } else if (is.list(doc)) {
                if (is.null(doc$markdown)) {
                    doc_string <- doc$description
                } else {
                    doc_string <- doc$markdown
                }
            }
            contents <- c(
                if (!is.null(def_text)) sprintf("```r\n%s\n```", def_text),
                doc_string
            )
        }
    }

    if (is.null(contents)) {
        Response$new(id)
    } else {
        Response$new(
            id,
            result = list(
                contents = contents,
                range = range(
                    start = document$to_lsp_position(row = range$start$row, col = range$start$col),
                    end = document$to_lsp_position(row = range$end$row, col = range$end$col)
                )
            )
        )
    }
}
